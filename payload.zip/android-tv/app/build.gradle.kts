plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.vasim.moviebox"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.vasim.moviebox"
        minSdk = 24
        targetSdk = 28
        versionCode = 1
        versionName = "0.1.30"
        ndk { abiFilters += listOf("armeabi-v7a", "arm64-v8a") }
    }

    // Fixed signing key: every build (including GitHub Actions) is signed with the same
    // certificate, so a new APK installs over the old one and keeps add-ons and settings.
    signingConfigs {
        create("fixed") {
            storeFile = file("moviebox.keystore")
            storePassword = "moviebox123"
            keyAlias = "moviebox"
            keyPassword = "moviebox123"
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("fixed") }
        getByName("release") { signingConfig = signingConfigs.getByName("fixed") }
    }

    packaging { jniLibs { useLegacyPackaging = true } }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    val v = providers.gradleProperty("termuxVer").getOrElse("v0.118.0")
    implementation("com.github.termux.termux-app:terminal-view:$v")
    implementation("com.github.termux.termux-app:terminal-emulator:$v")
}
