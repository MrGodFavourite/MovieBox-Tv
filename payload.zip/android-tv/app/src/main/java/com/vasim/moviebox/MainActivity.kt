package com.vasim.moviebox

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.Toast
import com.termux.terminal.TerminalSession
import com.termux.terminal.TerminalSessionClient
import com.termux.view.TerminalView
import com.termux.view.TerminalViewClient
import java.io.File

class MainActivity : Activity(), TerminalViewClient, TerminalSessionClient {

    private lateinit var terminalView: TerminalView
    private var session: TerminalSession? = null
    private var sessionDone = false
    private var textPx = 28
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var playFile: File

    // Catppuccin Mocha colours, to match the app's own theme.
    private val colBase = 0xFF1E1E2E.toInt()
    private val colMantle = 0xFF181825.toInt()
    private val colSurface = 0xFF313244.toInt()
    private val colText = 0xFFCDD6F4.toInt()
    private val colAccent = 0xFFCBA6F7.toInt()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    // ---------- start ----------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val isTv = packageManager.hasSystemFeature("android.software.leanback")
        terminalView = TerminalView(this, null)
        terminalView.setTerminalViewClient(this)
        val dm = resources.displayMetrics
        val shortSide = minOf(dm.widthPixels, dm.heightPixels)
        textPx = (shortSide / (if (isTv) 34 else 40)).coerceAtLeast(12)
        terminalView.setTextSize(textPx)
        terminalView.isFocusable = true
        terminalView.isFocusableInTouchMode = true

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(colBase)
        window.statusBarColor = colBase
        window.navigationBarColor = colMantle
        root.addView(terminalView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        if (!isTv) {
            root.addView(
                buildKeyRow(),
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            )
        }
        setContentView(root)

        playFile = File(filesDir, "play-request.txt")
        writeOpenScript()
        session = startSession()
        terminalView.attachSession(session)
        terminalView.requestFocus()
        terminalView.alpha = 0f
        terminalView.animate().alpha(1f).setDuration(350).start()

        handler.post(pollForPlayRequest)
    }

    private fun writeOpenScript() {
        // The Rust app calls this script with the video link as the last argument.
        val script = File(filesDir, "open.sh")
        script.writeText(
            "#!/system/bin/sh\n" +
                "for a; do U=\"\$a\"; done\n" +
                "printf '%s\\n' \"\$U\" > \"\$MOVIEBOX_FILES/play-request.tmp\"\n" +
                "mv \"\$MOVIEBOX_FILES/play-request.tmp\" \"\$MOVIEBOX_FILES/play-request.txt\"\n"
        )
        script.setExecutable(true, false)
    }

    private fun startSession(): TerminalSession {
        val env = HashMap<String, String>(System.getenv())
        env["TERM"] = "xterm-256color"
        env["COLORTERM"] = "truecolor"
        env["HOME"] = filesDir.absolutePath
        env["TMPDIR"] = cacheDir.absolutePath
        env["MOVIEBOX_FILES"] = filesDir.absolutePath
        env["MOVIEBOX_CONFIG_DIR"] = File(filesDir, "config").absolutePath
        env["MOVIEBOX_DATA_DIR"] = File(filesDir, "data").absolutePath
        env["MOVIEBOX_CACHE_DIR"] = File(cacheDir, "moviebox").absolutePath
        // Downloads go to the app's own storage folder on the device (no permission needed):
        // Android/data/com.vasim.moviebox/files/Download/MovieBox-TUI
        val dlDir = (getExternalFilesDir("Download") ?: File(filesDir, "Download")).apply { mkdirs() }
        env["MOVIEBOX_DOWNLOAD_DIR"] = dlDir.absolutePath
        env["MOVIEBOX_IMAGE_PROTOCOL"] = "halfblocks"
        env["MOVIEBOX_PLAYER"] = "android"
        env["MOVIEBOX_ANDROID_PLAYER_PATH"] = File(filesDir, "open.sh").absolutePath
        val envArray = env.map { "${it.key}=${it.value}" }.toTypedArray()

        val bin = File(applicationInfo.nativeLibraryDir, "libmoviebox.so").absolutePath
        return TerminalSession(bin, filesDir.absolutePath, arrayOf("moviebox-tui"), envArray, 2000, this)
    }

    // ---------- play videos: the app writes a link, we open the video player ----------

    private val pollForPlayRequest = object : Runnable {
        override fun run() {
            try {
                if (playFile.exists()) {
                    val url = playFile.readText().trim()
                    playFile.delete()
                    if (url.isNotEmpty()) openVideo(url)
                }
            } catch (_: Exception) {
            }
            handler.postDelayed(this, 500)
        }
    }

    private fun openVideo(url: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW)
            intent.setDataAndType(Uri.parse(url), "video/*")
            startActivity(Intent.createChooser(intent, "Play with"))
        } catch (e: Exception) {
            Toast.makeText(this, "No video player found. Install VLC.", Toast.LENGTH_LONG).show()
        }
    }

    // ---------- typing with the TV keyboard (press MENU on the remote) ----------

    // ---------- phone helpers: on-screen keys and keyboard ----------

    private fun showKeyboard() {
        terminalView.requestFocus()
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showSoftInput(terminalView, 0)
    }

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(terminalView.windowToken, 0)
    }

    private fun buildKeyRow(): HorizontalScrollView {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(dp(6), dp(6), dp(6), dp(6))
        fun key(label: String, action: () -> Unit) {
            val b = Button(this)
            b.text = label
            b.isAllCaps = false
            b.isFocusable = false
            b.isFocusableInTouchMode = false
            b.setTextColor(colText)
            b.textSize = 14f
            b.stateListAnimator = null
            b.minWidth = dp(48)
            b.minimumWidth = dp(48)
            b.minHeight = dp(44)
            b.minimumHeight = dp(44)
            b.setPadding(dp(14), 0, dp(14), 0)
            val shape = GradientDrawable()
            shape.setColor(colSurface)
            shape.cornerRadius = dp(22).toFloat()
            b.background = RippleDrawable(ColorStateList.valueOf(colAccent and 0x55FFFFFF), shape, null)
            b.setOnClickListener {
                b.animate().scaleX(0.92f).scaleY(0.92f).setDuration(70).withEndAction {
                    b.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                }.start()
                action()
            }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.setMargins(dp(3), 0, dp(3), 0)
            row.addView(b, lp)
        }
        key("Keyboard") { showKeyboard() }
        key("Hide") { hideKeyboard() }
        key("/") { send("/") }
        key("?") { send("?") }
        key("Esc") { send("\u001b") }
        key("Tab") { send("\t") }
        key("Up") { send("\u001b[A") }
        key("Down") { send("\u001b[B") }
        key("Left") { send("\u001b[D") }
        key("Right") { send("\u001b[C") }
        key("Enter") { send("\r") }
        key("PgUp") { send("\u001b[5~") }
        key("PgDn") { send("\u001b[6~") }
        key("Ctrl-C") { send("\u0003") }
        key("Type...") { showTypeDialog() }
        val scroll = HorizontalScrollView(this)
        scroll.setBackgroundColor(colMantle)
        scroll.addView(row)
        return scroll
    }

    private fun send(text: String) {
        val bytes = text.toByteArray(Charsets.UTF_8)
        session?.write(bytes, 0, bytes.size)
    }

    private fun showTypeDialog() {
        val box = EditText(this)
        box.isSingleLine = true
        AlertDialog.Builder(this)
            .setTitle("Type here")
            .setView(box)
            .setPositiveButton("Send + Enter") { _, _ -> send(box.text.toString() + "\r") }
            .setNeutralButton("Send") { _, _ -> send(box.text.toString()) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // Back reaches here only when the on-screen keyboard did NOT take it
    // (an open keyboard closes itself on Back). Then Back acts as Esc in the app.
    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (sessionDone) {
            finish()
            return
        }
        hideKeyboard()
        send("\u001b")
    }

    override fun onDestroy() {
        handler.removeCallbacks(pollForPlayRequest)
        session?.finishIfRunning()
        super.onDestroy()
    }

    // ---------- TerminalViewClient ----------

    // Pinch with two fingers to make the text bigger or smaller.
    override fun onScale(scale: Float): Float {
        if (scale < 0.9f || scale > 1.1f) {
            textPx = (textPx + (if (scale > 1f) 2 else -2)).coerceIn(10, 90)
            terminalView.setTextSize(textPx)
            return 1.0f
        }
        return scale
    }
    override fun onSingleTapUp(e: MotionEvent?) {
        showKeyboard()
    }
    override fun shouldBackButtonBeMappedToEscape(): Boolean = false
    override fun shouldEnforceCharBasedInput(): Boolean = false
    override fun shouldUseCtrlSpaceWorkaround(): Boolean = false
    override fun isTerminalViewSelected(): Boolean = true
    override fun copyModeChanged(copyMode: Boolean) {}

    override fun onKeyDown(keyCode: Int, e: KeyEvent?, session: TerminalSession?): Boolean {
        if (sessionDone && keyCode == KeyEvent.KEYCODE_BACK) {
            finish()
            return true
        }
        // TV remote D-pad: send the terminal sequences ourselves so the arrows and OK
        // always reach the app, whatever mode the terminal is in.
        val dpad = when (keyCode) {
            KeyEvent.KEYCODE_DPAD_UP -> "\u001b[A"
            KeyEvent.KEYCODE_DPAD_DOWN -> "\u001b[B"
            KeyEvent.KEYCODE_DPAD_RIGHT -> "\u001b[C"
            KeyEvent.KEYCODE_DPAD_LEFT -> "\u001b[D"
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> "\r"
            else -> null
        }
        if (dpad != null) {
            send(dpad)
            return true
        }
        if (keyCode == KeyEvent.KEYCODE_MENU || keyCode == KeyEvent.KEYCODE_SEARCH ||
            keyCode == KeyEvent.KEYCODE_PROG_RED || keyCode == KeyEvent.KEYCODE_INFO
        ) {
            showTypeDialog()
            return true
        }
        return false
    }

    override fun onKeyUp(keyCode: Int, e: KeyEvent?): Boolean = false
    override fun onLongPress(event: MotionEvent?): Boolean = false
    override fun readControlKey(): Boolean = false
    override fun readAltKey(): Boolean = false
    override fun readShiftKey(): Boolean = false
    override fun readFnKey(): Boolean = false
    override fun onCodePoint(codePoint: Int, ctrlDown: Boolean, session: TerminalSession?): Boolean = false
    override fun onEmulatorSet() {}

    // ---------- TerminalSessionClient ----------

    override fun onTextChanged(changedSession: TerminalSession) {
        terminalView.onScreenUpdated()
    }

    override fun onTitleChanged(changedSession: TerminalSession) {}
    override fun onSessionFinished(finishedSession: TerminalSession) {
        // Keep the screen open so any error message stays readable. Press Back to leave.
        sessionDone = true
        Toast.makeText(this, "MovieBox stopped (code " + finishedSession.exitStatus + "). Press Back to close.", Toast.LENGTH_LONG).show()
    }

    override fun onCopyTextToClipboard(session: TerminalSession, text: String?) {}
    override fun onPasteTextFromClipboard(session: TerminalSession?) {}
    override fun onBell(session: TerminalSession) {}
    override fun onColorsChanged(session: TerminalSession) {}
    override fun onTerminalCursorStateChange(state: Boolean) {}
    override fun getTerminalCursorStyle(): Int? = 0

    // ---------- logging (shared by both interfaces) ----------

    override fun logError(tag: String?, message: String?) {}
    override fun logWarn(tag: String?, message: String?) {}
    override fun logInfo(tag: String?, message: String?) {}
    override fun logDebug(tag: String?, message: String?) {}
    override fun logVerbose(tag: String?, message: String?) {}
    override fun logStackTraceWithMessage(tag: String?, message: String?, e: Exception?) {}
    override fun logStackTrace(tag: String?, e: Exception?) {}
}
