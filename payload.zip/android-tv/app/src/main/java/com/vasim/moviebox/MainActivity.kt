package com.vasim.moviebox

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.EditText
import android.widget.Toast
import com.termux.terminal.TerminalSession
import com.termux.terminal.TerminalSessionClient
import com.termux.view.TerminalView
import com.termux.view.TerminalViewClient
import java.io.File

class MainActivity : Activity(), TerminalViewClient, TerminalSessionClient {

    private lateinit var terminalView: TerminalView
    private var session: TerminalSession? = null
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var playFile: File

    // ---------- start ----------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        terminalView = TerminalView(this, null)
        terminalView.setTerminalViewClient(this)
        terminalView.setTypeface(Typeface.MONOSPACE)
        val textPx = (resources.displayMetrics.heightPixels / 34).coerceAtLeast(16)
        terminalView.setTextSize(textPx)
        terminalView.isFocusable = true
        terminalView.isFocusableInTouchMode = true
        setContentView(terminalView)

        playFile = File(filesDir, "play-request.txt")
        writeOpenScript()
        session = startSession()
        terminalView.attachSession(session)
        terminalView.requestFocus()

        handler.post(pollForPlayRequest)
    }

    private fun writeOpenScript() {
        // The Rust app calls this script with the video link as the last argument.
        val script = File(filesDir, "open.sh")
        script.writeText(
            "#!/system/bin/sh\n" +
                "for a; do U=\"\$a\"; done\n" +
                "printf '%s\\n' \"\$U\" > \"\$MOVIEBOX_FILES/play-request.tmp\"\n" +
                "mv \"\$MOVIEBOX_FILES/play-request.tmp\" \"\$MOVIEBOX_FILES/play-request.txt\"\n"
        )
        script.setExecutable(true, false)
    }

    private fun startSession(): TerminalSession {
        val env = HashMap<String, String>(System.getenv())
        env["TERM"] = "xterm-256color"
        env["COLORTERM"] = "truecolor"
        env["HOME"] = filesDir.absolutePath
        env["TMPDIR"] = cacheDir.absolutePath
        env["MOVIEBOX_FILES"] = filesDir.absolutePath
        env["MOVIEBOX_CONFIG_DIR"] = File(filesDir, "config").absolutePath
        env["MOVIEBOX_DATA_DIR"] = File(filesDir, "data").absolutePath
        env["MOVIEBOX_CACHE_DIR"] = File(cacheDir, "moviebox").absolutePath
        env["MOVIEBOX_NO_IMAGE"] = "1"
        env["MOVIEBOX_PLAYER"] = "android"
        env["MOVIEBOX_ANDROID_PLAYER_PATH"] = File(filesDir, "open.sh").absolutePath
        val envArray = env.map { "${it.key}=${it.value}" }.toTypedArray()

        val bin = File(applicationInfo.nativeLibraryDir, "libmoviebox.so").absolutePath
        return TerminalSession(bin, filesDir.absolutePath, arrayOf("moviebox-tui"), envArray, 2000, this)
    }

    // ---------- play videos: the app writes a link, we open the video player ----------

    private val pollForPlayRequest = object : Runnable {
        override fun run() {
            try {
                if (playFile.exists()) {
                    val url = playFile.readText().trim()
                    playFile.delete()
                    if (url.isNotEmpty()) openVideo(url)
                }
            } catch (_: Exception) {
            }
            handler.postDelayed(this, 500)
        }
    }

    private fun openVideo(url: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW)
            intent.setDataAndType(Uri.parse(url), "video/*")
            startActivity(Intent.createChooser(intent, "Play with"))
        } catch (e: Exception) {
            Toast.makeText(this, "No video player found. Install VLC.", Toast.LENGTH_LONG).show()
        }
    }

    // ---------- typing with the TV keyboard (press MENU on the remote) ----------

    private fun send(text: String) {
        val bytes = text.toByteArray(Charsets.UTF_8)
        session?.write(bytes, 0, bytes.size)
    }

    private fun showTypeDialog() {
        val box = EditText(this)
        box.isSingleLine = true
        AlertDialog.Builder(this)
            .setTitle("Type here")
            .setView(box)
            .setPositiveButton("Send + Enter") { _, _ -> send(box.text.toString() + "\r") }
            .setNeutralButton("Send") { _, _ -> send(box.text.toString()) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onDestroy() {
        handler.removeCallbacks(pollForPlayRequest)
        session?.finishIfRunning()
        super.onDestroy()
    }

    // ---------- TerminalViewClient ----------

    override fun onScale(scale: Float): Float = 1.0f
    override fun onSingleTapUp(e: MotionEvent?) {}
    override fun shouldBackButtonBeMappedToEscape(): Boolean = true
    override fun shouldEnforceCharBasedInput(): Boolean = false
    override fun shouldUseCtrlSpaceWorkaround(): Boolean = false
    override fun isTerminalViewSelected(): Boolean = true
    override fun copyModeChanged(copyMode: Boolean) {}

    override fun onKeyDown(keyCode: Int, e: KeyEvent?, session: TerminalSession?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_MENU || keyCode == KeyEvent.KEYCODE_SEARCH ||
            keyCode == KeyEvent.KEYCODE_PROG_RED || keyCode == KeyEvent.KEYCODE_INFO
        ) {
            showTypeDialog()
            return true
        }
        return false
    }

    override fun onKeyUp(keyCode: Int, e: KeyEvent?): Boolean = false
    override fun onLongPress(event: MotionEvent?): Boolean = false
    override fun readControlKey(): Boolean = false
    override fun readAltKey(): Boolean = false
    override fun readShiftKey(): Boolean = false
    override fun readFnKey(): Boolean = false
    override fun onCodePoint(codePoint: Int, ctrlDown: Boolean, session: TerminalSession?): Boolean = false
    override fun onEmulatorSet() {}

    // ---------- TerminalSessionClient ----------

    override fun onTextChanged(changedSession: TerminalSession) {
        terminalView.onScreenUpdated()
    }

    override fun onTitleChanged(changedSession: TerminalSession) {}
    override fun onSessionFinished(finishedSession: TerminalSession) {
        finish()
    }

    override fun onCopyTextToClipboard(session: TerminalSession, text: String?) {}
    override fun onPasteTextFromClipboard(session: TerminalSession?) {}
    override fun onBell(session: TerminalSession) {}
    override fun onColorsChanged(session: TerminalSession) {}
    override fun onTerminalCursorStateChange(state: Boolean) {}
    override fun getTerminalCursorStyle(): Int? = 0

    // ---------- logging (shared by both interfaces) ----------

    override fun logError(tag: String?, message: String?) {}
    override fun logWarn(tag: String?, message: String?) {}
    override fun logInfo(tag: String?, message: String?) {}
    override fun logDebug(tag: String?, message: String?) {}
    override fun logVerbose(tag: String?, message: String?) {}
    override fun logStackTraceWithMessage(tag: String?, message: String?, e: Exception?) {}
    override fun logStackTrace(tag: String?, e: Exception?) {}
}
