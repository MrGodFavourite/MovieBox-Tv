package com.vasim.moviebox

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.Manifest
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.os.SystemClock
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.Toast
import com.termux.terminal.TerminalSession
import com.termux.terminal.TerminalSessionClient
import com.termux.view.TerminalView
import com.termux.view.TerminalViewClient
import java.io.File

class MainActivity : Activity(), TerminalViewClient, TerminalSessionClient {

    companion object {
        private const val REQ_PLAY = 4242
    }

    private lateinit var terminalView: TerminalView
    private var session: TerminalSession? = null
    private var sessionDone = false
    private var textPx = 28
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var playFile: File
    private lateinit var prefs: SharedPreferences
    private var isTvDevice = false
    private var kbdShown = false
    private var asked = false

    // Catppuccin Mocha colours, to match the app's own theme.
    private val colBase = 0xFF1E1E2E.toInt()
    private val colMantle = 0xFF181825.toInt()
    private val colSurface = 0xFF313244.toInt()
    private val colText = 0xFFCDD6F4.toInt()
    private val colAccent = 0xFFCBA6F7.toInt()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    // ---------- start ----------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        prefs = getSharedPreferences("moviebox", MODE_PRIVATE)

        val isTv = packageManager.hasSystemFeature("android.software.leanback")
        isTvDevice = isTv
        terminalView = TerminalView(this, null)
        terminalView.setTerminalViewClient(this)
        val dm = resources.displayMetrics
        val shortSide = minOf(dm.widthPixels, dm.heightPixels)
        textPx = prefs.getInt("text_px", (shortSide / (if (isTv) 34 else 40)).coerceAtLeast(12))
        terminalView.setTextSize(textPx)
        terminalView.isFocusable = true
        // Remote-only UI: touch/mouse must never move focus or open the keyboard on a TV.
        if (isTv) terminalView.setOnTouchListener { _, _ -> true }
        terminalView.isFocusableInTouchMode = true

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(colBase)
        if (isTv) {
            // 5% overscan-safe margins on every edge
            root.setPadding(
                (dm.widthPixels * 0.05f).toInt(), (dm.heightPixels * 0.05f).toInt(),
                (dm.widthPixels * 0.05f).toInt(), (dm.heightPixels * 0.05f).toInt()
            )
        }
        window.statusBarColor = colBase
        window.navigationBarColor = colMantle
        root.addView(terminalView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        if (!isTv) {
            root.addView(
                buildKeyRow(),
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            )
        }
        setContentView(root)

        playFile = File(filesDir, "play-request.txt")
        writeOpenScript()
        restoreSettings()
        session = startSession()
        terminalView.attachSession(session)
        terminalView.requestFocus()
        terminalView.alpha = 0f
        terminalView.animate().alpha(1f).setDuration(350).start()

        handler.post(pollForPlayRequest)
        askStoragePermission()
        if (!prefs.getBoolean("hint_shown", false)) {
            prefs.edit().putBoolean("hint_shown", true).apply()
            Toast.makeText(this, "Press Menu for the quick menu.", Toast.LENGTH_LONG).show()
        }
    }

    // ---------- helpers ----------

    private fun send(s: String) {
        session?.write(s)
    }

    private fun showKeyboard() {
        terminalView.requestFocus()
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
        imm?.showSoftInput(terminalView, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
        imm?.hideSoftInputFromWindow(terminalView.windowToken, 0)
    }

    private fun showTypeDialog() {
        val input = EditText(this).apply {
            hint = "Type text or /command"
            setSingleLine(true)
        }
        AlertDialog.Builder(this)
            .setTitle("Type text")
            .setView(input)
            .setPositiveButton("Send") { _, _ ->
                val txt = input.text.toString()
                if (txt.isNotEmpty()) send(txt + "\r")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun buildKeyRow(): HorizontalScrollView {
        val scroll = HorizontalScrollView(this).apply {
            setBackgroundColor(colMantle)
            isHorizontalScrollBarEnabled = false
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(6), dp(4), dp(6), dp(4))
        }
        val keys = listOf(
            "Esc" to { send("\u001b") },
            "Tab" to { send("\t") },
            "↑" to { send("\u001b[A") },
            "↓" to { send("\u001b[B") },
            "←" to { send("\u001b[D") },
            "→" to { send("\u001b[C") },
            "Enter" to { send("\r") },
            "/" to { send("/") },
            "Kbd" to { showKeyboard() },
            "Type" to { showTypeDialog() },
            "Menu" to { showMenu() }
        )
        for ((label, action) in keys) {
            val bg = GradientDrawable().apply {
                setColor(colSurface)
                cornerRadius = dp(6).toFloat()
            }
            val ripple = RippleDrawable(ColorStateList.valueOf(colAccent), bg, null)
            val btn = Button(this).apply {
                text = label
                setTextColor(colText)
                textSize = 12f
                typeface = Typeface.MONOSPACE
                isAllCaps = false
                background = ripple
                setPadding(dp(10), dp(4), dp(10), dp(4))
                minWidth = 0
                minimumWidth = 0
                minHeight = 0
                minimumHeight = 0
                setOnClickListener { action() }
            }
            val lp = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(dp(3), 0, dp(3), 0)
            }
            row.addView(btn, lp)
        }
        scroll.addView(row)
        return scroll
    }

    // ---------- storage permission, so downloads can go to the public Download folder ----------

    private fun hasStorage(): Boolean =
        Build.VERSION.SDK_INT < 23 ||
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun askStoragePermission() {
        if (Build.VERSION.SDK_INT >= 23 && !hasStorage() && !asked) {
            asked = true
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE), 77)
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (code == 77 && hasStorage() &&
            (!prefs.getBoolean("restore_checked", false) || !prefs.contains("download_dir"))
        ) restartSession(true)
    }

    // ---------- backup of add-ons and settings in public storage (survives uninstall) ----------

    private val backupFiles = listOf(
        "config/addons_config.json",
        "config/config.json",
        "config/tv_config.json",
        "config/addons_seeded.json",
        "data/favorites.json",
        "data/history.json"
    )

    private fun backupDir(): File =
        File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "MovieBox-backup")

    // Runs once per install (the flag is wiped by an uninstall). Copies the backup into the
    // app's private folders before the Rust app starts. Only possible once storage is granted.
    private fun restoreSettings() {
        if (prefs.getBoolean("restore_checked", false) || !hasStorage()) return
        try {
            val src = backupDir()
            for (rel in backupFiles) {
                val f = File(src, File(rel).name)
                if (f.isFile && f.length() > 0) {
                    val dst = File(filesDir, rel)
                    dst.parentFile?.mkdirs()
                    f.copyTo(dst, overwrite = true)
                }
            }
        } catch (_: Exception) {
        }
        prefs.edit().putBoolean("restore_checked", true).apply()
    }

    private fun backupSettings() {
        if (!hasStorage() || !prefs.getBoolean("restore_checked", false)) return
        try {
            val dst = backupDir()
            dst.mkdirs()
            for (rel in backupFiles) {
                val f = File(filesDir, rel)
                if (f.isFile && f.length() > 0) f.copyTo(File(dst, File(rel).name), overwrite = true)
            }
        } catch (_: Exception) {
        }
    }

    override fun onStop() {
        backupSettings()
        super.onStop()
    }

    private fun restartSession(restore: Boolean = false) {
        session?.finishIfRunning()
        if (restore) restoreSettings()
        sessionDone = false
        session = startSession()
        terminalView.attachSession(session)
        terminalView.requestFocus()
    }

    private fun writeOpenScript() {
        // The Rust app calls this script with the video link as the last argument.
        val script = File(filesDir, "open.sh")
        script.writeText(
            "#!/system/bin/sh\n" +
                "for a; do U=\"\$a\"; done\n" +
                "printf '%s\\n' \"\$U\" > \"\$MOVIEBOX_FILES/play-request.tmp\"\n" +
                "mv \"\$MOVIEBOX_FILES/play-request.tmp\" \"\$MOVIEBOX_FILES/play-request.txt\"\n"
        )
        script.setExecutable(true, false)
    }

    private fun startSession(): TerminalSession {
        val env = HashMap<String, String>(System.getenv())
        env["TERM"] = "xterm-256color"
        env["COLORTERM"] = "truecolor"
        env["HOME"] = filesDir.absolutePath
        env["TMPDIR"] = cacheDir.absolutePath
        env["MOVIEBOX_FILES"] = filesDir.absolutePath
        env["MOVIEBOX_CONFIG_DIR"] = File(filesDir, "config").absolutePath
        env["MOVIEBOX_DATA_DIR"] = File(filesDir, "data").absolutePath
        env["MOVIEBOX_CACHE_DIR"] = File(cacheDir, "moviebox").absolutePath
        // Downloads go to the app's own storage folder on the device (no permission needed):
        // Android/data/com.vasim.moviebox/files/Download/MovieBox-TUI
        val appDl = (getExternalFilesDir("Download") ?: File(filesDir, "Download")).apply { mkdirs() }
        val publicDl = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        val chosen = prefs.getString("download_dir", null)
        env["MOVIEBOX_DOWNLOAD_DIR"] = (if (hasStorage()) publicDl else appDl).absolutePath
        if (chosen != null) env["MOVIEBOX_DOWNLOAD_DIR_FORCE"] = chosen
        env["MOVIEBOX_IMAGE_PROTOCOL"] = "halfblocks"
        env["MOVIEBOX_PLAYER"] = "android"
        env["MOVIEBOX_ANDROID_PLAYER_PATH"] = File(filesDir, "open.sh").absolutePath
        val envArray = env.map { "${it.key}=${it.value}" }.toTypedArray()

        val bin = File(applicationInfo.nativeLibraryDir, "libmoviebox.so").absolutePath
        return TerminalSession(bin, filesDir.absolutePath, arrayOf("moviebox-tui"), envArray, 2000, this)
    }

    // ---------- play videos: the app writes a link, we open the video player ----------

    private val pollForPlayRequest = object : Runnable {
        override fun run() {
            try {
                if (playFile.exists()) {
                    val url = playFile.readText().trim()
                    playFile.delete()
                    if (url.isNotEmpty()) openVideo(url)
                }
            } catch (_: Exception) {
            }
            handler.postDelayed(this, 500)
        }
    }

    private fun videoIntent(url: String): Intent =
        Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(Uri.parse(url), "video/*")
            putExtra("return_result", true) // MX-style protocol (mpv-android, Nova)
            putExtra("title", "MovieBox")
        }

    private fun launchPlayer(intent: Intent): Boolean =
        try {
            startActivityForResult(intent, REQ_PLAY)
            true
        } catch (_: Exception) {
            false
        }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_PLAY || data == null) return
        // mpv-android / Nova: position + duration in ms. VLC: extra_position / extra_duration.
        fun num(vararg keys: String): Long {
            for (k in keys) {
                val v = data.extras?.get(k)
                if (v is Number) return v.toLong()
            }
            return -1L
        }
        val pos = num("position", "extra_position")
        val dur = num("duration", "extra_duration")
        if (pos < 0) return
        val done = data.getStringExtra("end_by") == "playback_completion" ||
            (dur > 0 && pos >= dur * 0.9)
        syncProgress(pos, dur, done)
    }

    // Writes the player's position into the app's playback state file, then wakes the
    // Rust app with a focus-in sequence so it reconciles watch history.
    private fun syncProgress(posMs: Long, durMs: Long, completed: Boolean) {
        try {
            val dir = File(File(filesDir, "data"), "playback")
            val f = dir.listFiles { x -> x.name.endsWith(".json") }
                ?.maxByOrNull { it.lastModified() } ?: return
            var t = f.readText()
            fun setNum(key: String, v: String) {
                t = Regex("\"" + key + "\"\\s*:\\s*(null|-?\\d+)").replace(t) { "\"" + key + "\":" + v }
            }
            setNum("progress_seconds", (posMs / 1000).toString())
            if (durMs > 0) setNum("duration_seconds", (durMs / 1000).toString())
            setNum("timestamp", (System.currentTimeMillis() / 1000).toString())
            t = Regex("\"completed\"\\s*:\\s*(true|false)").replace(t, "\"completed\":" + completed)
            val tmp = File(f.parentFile, f.name + ".tmp")
            tmp.writeText(t)
            tmp.renameTo(f)
            send("\u001b[I")
        } catch (_: Exception) {
        }
    }

    private fun openVideo(url: String) {
        val saved = prefs.getString("player_pkg", null)
        if (saved != null) {
            if (launchPlayer(videoIntent(url).setPackage(saved))) return
            // player was uninstalled: forget it and ask again
            prefs.edit().remove("player_pkg").apply()
        }
        pickPlayer(url)
    }

    private fun pickPlayer(url: String?) {
        val probe = videoIntent(url ?: "http://example.com/video.mp4")
        val apps = packageManager.queryIntentActivities(probe, 0)
            .distinctBy { it.activityInfo.packageName }
        if (apps.isEmpty()) {
            Toast.makeText(this, "No video player found. Install MPV, VLC or Nova.", Toast.LENGTH_LONG).show()
            return
        }
        val labels = apps.map { it.loadLabel(packageManager).toString() }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(if (url != null) "Play with" else "Choose default player")
            .setItems(labels) { _, i ->
                val pkg = apps[i].activityInfo.packageName
                if (url == null) {
                    prefs.edit().putString("player_pkg", pkg).apply()
                    Toast.makeText(this, "Default player: " + labels[i], Toast.LENGTH_SHORT).show()
                } else {
                    AlertDialog.Builder(this)
                        .setTitle("Use " + labels[i] + " every time?")
                        .setPositiveButton("Always") { _, _ ->
                            prefs.edit().putString("player_pkg", pkg).apply()
                            launchPlayer(videoIntent(url).setPackage(pkg))
                        }
                        .setNegativeButton("Just once") { _, _ ->
                            launchPlayer(videoIntent(url).setPackage(pkg))
                        }
                        .show()
                }
            }
            .setNeutralButton(if (url == null) "Ask every time" else "Cancel") { _, _ ->
                if (url == null) prefs.edit().remove("player_pkg").apply()
            }
            .show()
    }

    // ---------- download folder ----------

    private fun pickDownloadFolder() {
        val names = ArrayList<String>()
        val paths = ArrayList<String?>()
        names.add("Default (reset)"); paths.add(null)
        if (hasStorage()) {
            names.add("Downloads folder")
            paths.add(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).absolutePath)
            names.add("Movies folder")
            paths.add(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES).absolutePath)
        }
        getExternalFilesDirs(null).filterNotNull().forEachIndexed { i, d ->
            names.add(if (i == 0) "App storage (internal)" else "SD card / USB: " + d.absolutePath.substringBefore("/Android"))
            paths.add(File(d, "Download").absolutePath)
        }
        AlertDialog.Builder(this)
            .setTitle("Download folder")
            .setItems(names.toTypedArray()) { _, i ->
                val p = paths[i]
                if (p == null) prefs.edit().remove("download_dir").apply()
                else prefs.edit().putString("download_dir", p).apply()
                restartSession()
                Toast.makeText(this, "Downloads: " + (p ?: "default"), Toast.LENGTH_LONG).show()
            }
            .show()
    }

    // ---------- menu (Menu / Info key on the remote) ----------

    private fun setTextSize(px: Int) {
        textPx = px.coerceIn(10, 90)
        prefs.edit().putInt("text_px", textPx).apply()
        terminalView.setTextSize(textPx)
    }

    private fun showMenu() {
        val items = arrayOf(
            "Favorite / Unfavorite",
            "Search",
            "Browse",
            "Watch history",
            "Favorites",
            "Addons / TV sources",
            "Live TV channels",
            "Settings",
            "Help",
            "Type text",
            "Default video player",
            "Download folder",
            "Text bigger",
            "Text smaller (sharper posters)",
            "Exit app"
        )
        AlertDialog.Builder(this)
            .setTitle("Go to")
            .setItems(items) { _, i ->
                when (i) {
                    0 -> toggleFavorite()
                    1 -> send("/")
                    2 -> send("/browse\r")
                    3 -> send("/history\r")
                    4 -> send("/favorites\r")
                    5 -> send("/config\r")
                    6 -> send("/list\r")
                    7 -> send("/settings\r")
                    8 -> send("/help\r")
                    9 -> showTypeDialog()
                    10 -> pickPlayer(null)
                    11 -> pickDownloadFolder()
                    12 -> setTextSize(textPx + 2)
                    13 -> setTextSize(textPx - 2)
                    14 -> finish()
                }
            }
            .show()
    }

    // Favorite / unfavorite the highlighted title (the app's own "f" key). Works on the
    // home list, Continue Watching, favorites and the details screen. Not while a text
    // box is open, because the key would be typed into it.
    private fun toggleFavorite() {
        if (kbdShown) {
            Toast.makeText(this, "Close the keyboard first.", Toast.LENGTH_SHORT).show()
            return
        }
        send("f")
    }

    // Back = Esc: the app unwinds one layer per press and asks "Press Back again to
    // exit" at the root, so a single Back never closes the app.
    private fun handleBack() {
        if (sessionDone) {
            finish()
            return
        }
        send("\u001b")
    }

    // Back reaches here only when the on-screen keyboard did NOT take it
    // (an open keyboard closes itself on Back). Then Back acts as Esc in the app.
    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        handleBack()
    }

    // The Rust process keeps running across onPause/onStop (playback and the proxy
    // stay alive while the external player is in front). It is stopped only when the
    // activity is really finishing, together with its proxy children.
    override fun onDestroy() {
        handler.removeCallbacks(pollForPlayRequest)
        if (isFinishing) {
            backupSettings()
            session?.finishIfRunning()
            super.onDestroy()
            android.os.Process.killProcess(android.os.Process.myPid())
            return
        }
        super.onDestroy()
    }

    // ---------- D-pad: one handler, key-down only, no double triggers ----------

    private var lastKeyAt = 0L

    private fun sequenceFor(keyCode: Int): String? = when (keyCode) {
        KeyEvent.KEYCODE_DPAD_UP -> "\u001b[A"
        KeyEvent.KEYCODE_DPAD_DOWN -> "\u001b[B"
        KeyEvent.KEYCODE_DPAD_RIGHT -> "\u001b[C"
        KeyEvent.KEYCODE_DPAD_LEFT -> "\u001b[D"
        KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> "\r"
        KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, KeyEvent.KEYCODE_MEDIA_PLAY, KeyEvent.KEYCODE_MEDIA_PAUSE -> " "
        KeyEvent.KEYCODE_PAGE_UP, KeyEvent.KEYCODE_CHANNEL_UP -> "\u001b[5~"
        KeyEvent.KEYCODE_PAGE_DOWN, KeyEvent.KEYCODE_CHANNEL_DOWN -> "\u001b[6~"
        KeyEvent.KEYCODE_MEDIA_FAST_FORWARD, KeyEvent.KEYCODE_TAB -> "\t"
        KeyEvent.KEYCODE_MEDIA_REWIND -> "\u001b[Z"
        KeyEvent.KEYCODE_PROG_YELLOW -> if (kbdShown) null else "f"
        in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 ->
            if (kbdShown) null else ('0' + (keyCode - KeyEvent.KEYCODE_0)).toString()
        in KeyEvent.KEYCODE_NUMPAD_0..KeyEvent.KEYCODE_NUMPAD_9 ->
            if (kbdShown) null else ('0' + (keyCode - KeyEvent.KEYCODE_NUMPAD_0)).toString()
        else -> null
    }

    // Remote OK: a short press is Enter (sent when the button is released), holding it for
    // about half a second opens the Menu dialog instead (Favorite / Unfavorite is first).
    private var okDown = false
    private var okDownAt = 0L
    private var okLongHandled = false

    private fun handleRemoteOk(e: KeyEvent): Boolean {
        val now = SystemClock.uptimeMillis()
        if (e.action == KeyEvent.ACTION_DOWN) {
            if (e.repeatCount == 0) {
                okDown = true
                okDownAt = now
                okLongHandled = false
            } else if (okDown && !okLongHandled && now - okDownAt >= 450) {
                okLongHandled = true
                showMenu()
            }
            return true
        }
        if (e.action == KeyEvent.ACTION_UP) {
            val wasDown = okDown
            val handled = okLongHandled
            val heldMs = now - okDownAt
            okDown = false
            okLongHandled = false
            if (!wasDown || handled) return true
            if (heldMs >= 600) {
                showMenu()
            } else {
                lastKeyAt = now
                send("\r")
            }
        }
        return true
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val code = e.keyCode
        if (code == KeyEvent.KEYCODE_DPAD_CENTER && !kbdShown) return handleRemoteOk(e)
        val isBack = code == KeyEvent.KEYCODE_BACK || code == KeyEvent.KEYCODE_ESCAPE
        val seq = sequenceFor(code)
        if (!isBack && seq == null) return super.dispatchKeyEvent(e)
        if (e.action != KeyEvent.ACTION_DOWN) return true // swallow key-up
        if (isBack) {
            if (e.repeatCount == 0) handleBack()
            return true
        }
        val now = SystemClock.uptimeMillis()
        if (e.repeatCount > 0) {
            // held key: allow scrolling, but never faster than ~16 steps/s,
            // and never repeat OK / Play-Pause
            if (seq == "\r" || seq == " " || now - lastKeyAt < 60) return true
        }
        lastKeyAt = now
        send(seq!!)
        return true
    }

    // ---------- TerminalViewClient ----------

    // Pinch with two fingers to make the text bigger or smaller.
    override fun onScale(scale: Float): Float {
        if (scale < 0.9f || scale > 1.1f) {
            setTextSize(textPx + (if (scale > 1f) 2 else -2))
            return 1.0f
        }
        return scale
    }
    override fun onSingleTapUp(e: MotionEvent?) {
        if (!isTvDevice) showKeyboard()
    }
    override fun shouldBackButtonBeMappedToEscape(): Boolean = false
    override fun shouldEnforceCharBasedInput(): Boolean = false
    override fun shouldUseCtrlSpaceWorkaround(): Boolean = false
    override fun isTerminalViewSelected(): Boolean = true
    override fun copyModeChanged(copyMode: Boolean) {}

    override fun onKeyDown(keyCode: Int, e: KeyEvent?, session: TerminalSession?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_MENU || keyCode == KeyEvent.KEYCODE_INFO) {
            showMenu()
            return true
        }
        if (keyCode == KeyEvent.KEYCODE_SEARCH || keyCode == KeyEvent.KEYCODE_PROG_RED) {
            showTypeDialog()
            return true
        }
        return false
    }

    override fun onKeyUp(keyCode: Int, e: KeyEvent?): Boolean = false
    override fun onLongPress(event: MotionEvent?): Boolean = false
    override fun readControlKey(): Boolean = false
    override fun readAltKey(): Boolean = false
    override fun readShiftKey(): Boolean = false
    override fun readFnKey(): Boolean = false
    override fun onCodePoint(codePoint: Int, ctrlDown: Boolean, session: TerminalSession?): Boolean = false
    override fun onEmulatorSet() {}

    // ---------- TerminalSessionClient ----------

    override fun onTextChanged(changedSession: TerminalSession) {
        terminalView.onScreenUpdated()
    }

    // The Rust app sets the terminal title to mb:kbd:on / mb:kbd:off while a text box
    // has focus, so the soft keyboard opens for typing and closes on Enter / Back.
    override fun onTitleChanged(changedSession: TerminalSession) {
        when (changedSession.title) {
            "mb:kbd:on" -> handler.post { kbdShown = true; showKeyboard() }
            "mb:kbd:off" -> handler.post { kbdShown = false; hideKeyboard(); terminalView.requestFocus() }
        }
    }
    override fun onSessionFinished(finishedSession: TerminalSession) {
        // Keep the screen open so any error message stays readable. Press Back to leave.
        sessionDone = true
        if (finishedSession.exitStatus == 0) {
            finish() // normal exit after "Press Back again to exit"
            return
        }
        Toast.makeText(this, "MovieBox stopped (code " + finishedSession.exitStatus + "). Press Back to close.", Toast.LENGTH_LONG).show()
    }

    override fun onCopyTextToClipboard(session: TerminalSession, text: String?) {}
    override fun onPasteTextFromClipboard(session: TerminalSession?) {}
    override fun onBell(session: TerminalSession) {}
    override fun onColorsChanged(session: TerminalSession) {}
    override fun onTerminalCursorStateChange(state: Boolean) {}
    override fun getTerminalCursorStyle(): Int? = 0

    // ---------- logging (shared by both interfaces) ----------

    override fun logError(tag: String?, message: String?) {}
    override fun logWarn(tag: String?, message: String?) {}
    override fun logInfo(tag: String?, message: String?) {}
    override fun logDebug(tag: String?, message: String?) {}
    override fun logVerbose(tag: String?, message: String?) {}
    override fun logStackTraceWithMessage(tag: String?, message: String?, e: Exception?) {}
    override fun logStackTrace(tag: String?, e: Exception?) {}
}
