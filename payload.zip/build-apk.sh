#!/bin/bash
cd "$(dirname "$0")/android-tv"
ok=0
for pass in 1 2; do
  for v in v0.118.0 v0.118.1 0.118.1; do
    echo "=== Trying terminal library $v ==="
    if gradle assembleDebug -PtermuxVer=$v --no-daemon; then ok=1; break 2; fi
  done
  sleep 90
done
test "$ok" = 1
