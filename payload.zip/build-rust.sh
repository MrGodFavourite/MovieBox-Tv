#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/moviebox"
NDK="${ANDROID_NDK_LATEST_HOME:-$ANDROID_NDK_HOME}"
T="$NDK/toolchains/llvm/prebuilt/linux-x86_64/bin"
export PATH="$T:$PATH"
export CARGO_TARGET_ARMV7_LINUX_ANDROIDEABI_LINKER="$T/armv7a-linux-androideabi24-clang"
export CC_armv7_linux_androideabi="$T/armv7a-linux-androideabi24-clang"
export AR_armv7_linux_androideabi="$T/llvm-ar"
export CARGO_TARGET_AARCH64_LINUX_ANDROID_LINKER="$T/aarch64-linux-android24-clang"
export CC_aarch64_linux_android="$T/aarch64-linux-android24-clang"
export AR_aarch64_linux_android="$T/llvm-ar"
export CARGO_TARGET_AARCH64_LINUX_ANDROID_RUSTFLAGS="-C link-arg=-Wl,-z,max-page-size=16384"
rustup target add armv7-linux-androideabi aarch64-linux-android
cargo build --release --target armv7-linux-androideabi --target aarch64-linux-android
file target/armv7-linux-androideabi/release/moviebox-tui target/aarch64-linux-android/release/moviebox-tui
J=../android-tv/app/src/main/jniLibs
mkdir -p $J/armeabi-v7a $J/arm64-v8a
cp target/armv7-linux-androideabi/release/moviebox-tui $J/armeabi-v7a/libmoviebox.so
cp target/aarch64-linux-android/release/moviebox-tui $J/arm64-v8a/libmoviebox.so
