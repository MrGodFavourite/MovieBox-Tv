use crate::providers::models::ProviderKind;
use ratatui::widgets::{ListState, TableState};

pub use crate::player::PlayerKind;

#[derive(Debug, Default, Clone, Copy, PartialEq, Eq)]
pub enum Screen {
    #[default]
    Home,
    Details,
}

#[derive(Debug, Default, Clone, Copy, PartialEq, Eq)]
pub enum DetailsPane {
    #[default]
    Streams,
    Seasons,
    Episodes,
    Languages,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum AppMode {
    Streaming,
    Tv,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum HomeDeckTab {
    #[default]
    ContinueWatching,
    Favorites,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum HomeTopFocus {
    #[default]
    None,
    Search,
    Provider,
}

#[derive(Debug, Default, Clone, Copy, PartialEq, Eq)]
pub enum InputMode {
    #[default]
    Normal,
    Editing,
}
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum SettingsCategory {
    #[default]
    General,
    ContentModes,
    Appearance,
    StorageInfo,
}

impl SettingsCategory {
    pub const ALL: [Self; 4] = [
        Self::General,
        Self::ContentModes,
        Self::Appearance,
        Self::StorageInfo,
    ];

    pub fn title(self) -> &'static str {
        match self {
            Self::General => "General",
            Self::ContentModes => "Content Modes",
            Self::Appearance => "Appearance",
            Self::StorageInfo => "Maintenance",
        }
    }
    pub fn compact_title(self) -> &'static str {
        match self {
            Self::General => "1:Gen",
            Self::ContentModes => "2:Modes",
            Self::Appearance => "3:Theme",
            Self::StorageInfo => "4:Info",
        }
    }

    pub fn badge(self) -> &'static str {
        match self {
            Self::General => "GEN",
            Self::ContentModes => "MODES",
            Self::Appearance => "THEME",
            Self::StorageInfo => "MAINT",
        }
    }

    pub fn row_count(self) -> usize {
        match self {
            Self::General => 3,
            Self::ContentModes => 3,
            Self::Appearance => 1,
            Self::StorageInfo => 5,
        }
    }
    pub fn next(self) -> Self {
        match self {
            Self::General => Self::ContentModes,
            Self::ContentModes => Self::Appearance,
            Self::Appearance => Self::StorageInfo,
            Self::StorageInfo => Self::General,
        }
    }

    pub fn previous(self) -> Self {
        match self {
            Self::General => Self::StorageInfo,
            Self::ContentModes => Self::General,
            Self::Appearance => Self::ContentModes,
            Self::StorageInfo => Self::Appearance,
        }
    }
}

pub fn settings_player_label(choice: Option<&str>) -> &'static str {
    match choice {
        None | Some("auto") => "None",
        Some("mpv") => "MPV",
        Some("vlc") => "VLC",
        Some("iina") => "IINA",
        Some("android") => "Android Player",
        Some(_) => "Custom",
    }
}

pub use crate::models::{
    AudioTrackOption, BrowseMetric, BrowseMetrics, BrowsePreset, CatalogItem, Episode,
    MediaDetails, MediaType, Notification, NotificationKind, Release, SearchResult, Season,
    SourceMirror, SubjectStreamPool,
};

pub type HomepageCacheData = (
    Vec<CatalogItem>,
    std::collections::HashMap<String, BrowseMetrics>,
);
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct ResultMetrics {
    pub poster_rows_eff: u16,
    pub row_height: u16,
    pub visible_items: usize,
    pub columns: u16,
    pub col_width: u16,
}

pub fn result_columns_for(width: u16) -> u16 {
    if width < 110 {
        1
    } else if width < 160 {
        2
    } else if width < 220 {
        3
    } else if width < 280 {
        4
    } else {
        5
    }
}

pub struct AppState {
    pub active_provider: ProviderKind,
    pub provider_generation: u64,
    pub active_screen: Screen,
    pub dirty: bool,
    pub input_mode: InputMode,
    pub search_query: crate::tui::text::TextInputBuffer,
    pub last_suggest_query: String,
    pub last_search_edit: std::time::Instant,
    pub search_suggestions: Vec<String>,
    pub suggest_index: Option<usize>,
    pub suggest_cache: lru::LruCache<String, Vec<String>>,
    pub homepage_cache: lru::LruCache<(String, usize), HomepageCacheData>,
    pub search_results: Vec<SearchResult>,
    pub search_error: Option<String>,
    pub search_exhausted: bool,
    pub is_homepage_mode: bool,
    pub current_tab_id: String,
    pub current_page: usize,
    pub search_posters: lru::LruCache<String, std::sync::Arc<image::DynamicImage>>,
    pub failed_posters: lru::LruCache<String, std::time::Instant>,
    pub search_poster_protocols:
        lru::LruCache<String, ((u16, u16), ratatui_image::protocol::Protocol)>,
    pub poster_fetch_semaphore: std::sync::Arc<tokio::sync::Semaphore>,
    pub in_flight_posters: std::collections::HashSet<String>,
    pub search_list_state: TableState,

    pub selected_details: Option<MediaDetails>,
    pub active_subject_id: Option<String>,
    pub selected_resources: Vec<Release>,
    pub addon_stream_statuses: Vec<crate::providers::addons::AddonStreamStatus>,
    pub addon_stream_filter: Option<String>,
    pub stream_pool: std::collections::HashMap<String, SubjectStreamPool>,
    pub fetch_cancel: std::sync::Arc<std::sync::atomic::AtomicBool>,
    pub is_waiting_for_download_stream: bool,
    pub auto_play_on_ready: bool,
    pub is_fetching_streams: bool,
    pub stream_error: Option<String>,
    pub details_error: Option<String>,
    pub preview_cache: lru::LruCache<String, MediaDetails>,
    pub resource_list_state: TableState,

    pub details_pane: DetailsPane,
    pub selected_season: usize,
    pub selected_episode: usize,
    pub season_list_state: ListState,
    pub episode_list_state: ListState,
    pub language_list_state: ListState,
    pub available_seasons: Vec<Season>,
    pub available_episode_numbers: Vec<Vec<usize>>,

    pub search_preview: Option<MediaDetails>,
    pub preview_loading: bool,

    pub tick_count: u64,
    pub poster_image: Option<std::sync::Arc<image::DynamicImage>>,

    pub show_theme_popup: bool,
    pub active_theme_kind: String,
    pub theme_is_auto: bool,
    pub original_theme_kind: Option<String>,
    pub theme_list_state: ListState,
    pub show_browse_popup: bool,
    pub browse_list_state: ListState,
    pub active_browse_preset: Option<BrowsePreset>,
    pub active_addon_catalog: Option<crate::providers::addons::models::AddonCatalogTarget>,
    pub show_provider_popup: bool,
    pub provider_list_state: ListState,
    pub browse_metrics: std::collections::HashMap<String, BrowseMetrics>,
    pub show_settings_popup: bool,
    pub settings_category: SettingsCategory,
    pub settings_selected_row: usize,
    pub settings_download_dir_input: Option<crate::tui::text::TextInputBuffer>,
    pub show_sources_popup: bool,
    pub sources_list_state: ListState,

    pub poster_protocol: Option<(ratatui::layout::Rect, ratatui_image::protocol::Protocol)>,
    pub image_picker: Option<ratatui_image::picker::Picker>,
    pub image_supported: bool,
    pub clear_terminal_before_draw: bool,
    pub poster_rows: u16,
    pub image_cache: lru::LruCache<String, std::sync::Arc<image::DynamicImage>>,

    pub show_help: bool,
    pub help_scroll: usize,
    pub cursor_beam: bool,
    pub last_result_metrics: Option<ResultMetrics>,
    pub result_scroll: usize,

    pub active_resource_request: u64,
    pub active_search_request: u64,
    pub active_homepage_request: u64,
    pub active_details_request: u64,
    pub active_preview_request: u64,
    pub active_suggest_request: u64,
    pub pending_episode_fetch: Option<(String, usize, usize)>,
    pub last_episode_nav: std::time::Instant,
    pub pending_preview_fetch: Option<String>,
    pub last_preview_nav: std::time::Instant,
    pub last_resize_time: Option<(std::time::Instant, u16, u16)>,
    pub last_term_size: Option<(u16, u16)>,
    pub player_picker_popup: bool,
    pub player_picker_state: ListState,
    pub settings_player_picker: bool,
    pub available_players: Vec<PlayerKind>,
    pub default_player: Option<String>,
    pub vlc_path: Option<String>,
    pub mpv_path: Option<String>,
    pub iina_path: Option<String>,
    pub is_loading: bool,
    pub is_resolving_playback: bool,
    pub has_streams_settled: bool,
    pub has_search_settled: bool,
    pub is_playing: bool,
    pub last_playback_launch: std::time::Instant,
    pub status_message: String,
    pub status_timer: usize,
    pub notifications: std::collections::VecDeque<crate::tui::overlay::Notification>,
    pub update_available: Option<(String, String)>,
    pub auto_update: bool,
    pub last_update_check: u64,
    pub manual_update_check: bool,
    pub is_checking_updates: bool,
    pub is_updating: bool,
    pub update_release: Option<crate::updater::Release>,
    pub update_progress_msg: Option<String>,
    pub update_target_exe: Option<std::path::PathBuf>,
    pub download_progress: Option<f64>,
    pub download_status: Option<String>,
    pub download_title: Option<String>,
    pub cancel_download: std::sync::Arc<std::sync::atomic::AtomicBool>,
    pub download_dir: Option<std::path::PathBuf>,

    pub download_queue: std::collections::VecDeque<(usize, usize)>,
    pub download_queue_total: usize,

    pub language_chosen: bool,

    pub subtitle_popup: bool,
    pub is_download_subtitle_popup: bool,
    pub season_subtitle_preference: Option<Option<String>>,
    pub last_download_subtitle_language: Option<String>,
    pub subtitle_list: Vec<(String, String)>,
    pub subtitle_list_state: ListState,
    pub pending_play_link: Option<String>,
    pub pending_playback_source: Option<crate::providers::models::PlaybackSource>,
    pub show_overview_modal: bool,
    pub overview_modal_scroll: usize,
    pub overview_modal_title: String,
    pub overview_modal_content: String,
    pub basic_terminal: bool,
    pub moviebox_enabled: bool,
    pub fourkhdhub_enabled: bool,
    pub dramachi_enabled: bool,
    pub bdix_circleftp_enabled: bool,
    pub bdix_dhakaflix_enabled: bool,
    pub bdix_probed: bool,
    pub streaming_enabled: bool,

    pub is_tv_mode: bool,
    pub tv_enabled: bool,
    pub tv_config_popup: bool,
    pub tv_channels: Vec<crate::providers::tv::Channel>,
    pub tv_playlists: Vec<String>,
    pub tv_manager_selected: usize,
    pub tv_input_active: bool,
    pub tv_input_buffer: crate::tui::text::TextInputBuffer,
    pub tv_input_is_file: bool,

    pub addons_enabled: bool,
    pub installed_addons: Vec<crate::providers::addons::models::InstalledAddon>,
    pub addon_manager_popup: bool,
    pub addon_manager_selected: usize,
    pub addon_input_active: bool,
    pub addon_input_buffer: crate::tui::text::TextInputBuffer,
    pub history: crate::history::HistoryManager,
    pub favorites: crate::favorites::FavoritesManager,
    pub favorites_focus: bool,
    /// Back pressed once at the root screen; a second press within 2 s exits.
    pub exit_armed_at: Option<std::time::Instant>,
    /// Whether the Android wrapper has been asked to show its soft keyboard.
    pub ime_shown: bool,
    /// D-pad / keyboard focus on the "Discover Categories" rows of the empty home screen.
    pub discover_focus: Option<usize>,
    /// D-pad focus on the top search bar or provider pill on the home screen.
    pub home_top_focus: HomeTopFocus,
    pub home_deck_tab: HomeDeckTab,
    pub favorites_landing_state: ListState,
}

impl Default for AppState {
    fn default() -> Self {
        Self {
            active_provider: ProviderKind::MovieBox,
            provider_generation: 0,
            active_screen: Screen::Home,
            dirty: true,
            input_mode: InputMode::Normal,
            search_query: crate::tui::text::TextInputBuffer::new(),
            last_suggest_query: String::new(),
            last_search_edit: std::time::Instant::now(),
            search_suggestions: Vec::new(),
            suggest_index: None,
            suggest_cache: lru::LruCache::new(cache_capacity(128)),
            homepage_cache: lru::LruCache::new(cache_capacity(32)),
            search_results: Vec::new(),
            search_error: None,
            search_exhausted: false,
            is_homepage_mode: false,
            current_tab_id: String::new(),
            current_page: 1,
            search_posters: lru::LruCache::new(cache_capacity(96)),
            failed_posters: lru::LruCache::new(cache_capacity(300)),
            search_poster_protocols: lru::LruCache::new(cache_capacity(128)),
            poster_fetch_semaphore: std::sync::Arc::new(tokio::sync::Semaphore::new(4)),
            in_flight_posters: std::collections::HashSet::new(),
            search_list_state: TableState::default(),
            basic_terminal: crate::tui::terminal::uses_basic_ui(),
            selected_details: None,
            active_subject_id: None,
            selected_resources: vec![],
            addon_stream_statuses: vec![],
            addon_stream_filter: None,
            stream_pool: std::collections::HashMap::new(),
            fetch_cancel: std::sync::Arc::new(std::sync::atomic::AtomicBool::new(false)),
            is_waiting_for_download_stream: false,
            is_fetching_streams: false,
            auto_play_on_ready: false,
            stream_error: None,
            details_error: None,
            resource_list_state: TableState::default(),
            preview_cache: lru::LruCache::new(cache_capacity(64)),
            details_pane: DetailsPane::default(),
            selected_season: 1,
            selected_episode: 1,
            season_list_state: ListState::default(),
            episode_list_state: ListState::default(),
            language_list_state: ListState::default(),
            available_seasons: vec![],
            available_episode_numbers: vec![],

            search_preview: None,
            preview_loading: false,
            tick_count: 0,
            poster_image: None,
            active_theme_kind: String::new(),
            theme_is_auto: true,
            original_theme_kind: None,
            show_theme_popup: false,
            theme_list_state: ListState::default(),
            show_browse_popup: false,
            browse_list_state: ListState::default(),
            active_browse_preset: None,
            active_addon_catalog: None,
            show_provider_popup: false,
            provider_list_state: ListState::default(),
            browse_metrics: std::collections::HashMap::new(),
            show_settings_popup: false,
            settings_category: SettingsCategory::General,
            settings_selected_row: 0,
            settings_download_dir_input: None,
            show_sources_popup: false,
            sources_list_state: ListState::default(),

            poster_protocol: None,
            image_picker: None,
            image_supported: crate::tui::terminal::should_query_images(),
            clear_terminal_before_draw: false,
            poster_rows: 3,
            image_cache: lru::LruCache::new(cache_capacity(10)),
            show_help: false,
            help_scroll: 0,
            cursor_beam: false,
            last_result_metrics: None,
            result_scroll: 0,
            active_resource_request: 0,
            active_search_request: 0,
            active_homepage_request: 0,
            active_details_request: 0,
            active_preview_request: 0,
            active_suggest_request: 0,
            pending_episode_fetch: None,
            last_episode_nav: std::time::Instant::now(),
            pending_preview_fetch: None,
            last_preview_nav: std::time::Instant::now(),
            last_resize_time: None,
            last_term_size: crossterm::terminal::size().ok(),
            player_picker_popup: false,
            player_picker_state: ListState::default(),
            settings_player_picker: false,
            available_players: Vec::new(),
            default_player: None,
            vlc_path: None,
            mpv_path: None,
            iina_path: None,
            is_loading: false,
            is_resolving_playback: false,
            has_streams_settled: false,
            has_search_settled: false,
            is_playing: false,
            last_playback_launch: std::time::Instant::now()
                .checked_sub(std::time::Duration::from_secs(5))
                .unwrap_or_else(std::time::Instant::now),
            status_message: String::new(),
            status_timer: 0,
            notifications: std::collections::VecDeque::new(),
            update_available: None,
            auto_update: true,
            last_update_check: 0,
            manual_update_check: false,
            is_checking_updates: false,
            is_updating: false,
            update_release: None,
            update_progress_msg: None,
            update_target_exe: None,
            download_progress: None,
            download_status: None,
            download_title: None,
            cancel_download: std::sync::Arc::new(std::sync::atomic::AtomicBool::new(false)),
            download_dir: None,
            download_queue: std::collections::VecDeque::new(),
            download_queue_total: 0,
            language_chosen: false,

            subtitle_popup: false,
            is_download_subtitle_popup: false,
            season_subtitle_preference: None,
            last_download_subtitle_language: None,
            subtitle_list: Vec::new(),
            subtitle_list_state: ListState::default(),
            pending_play_link: None,
            pending_playback_source: None,
            show_overview_modal: false,
            overview_modal_scroll: 0,
            overview_modal_title: String::new(),
            overview_modal_content: String::new(),
            moviebox_enabled: true,
            fourkhdhub_enabled: true,
            dramachi_enabled: true,
            bdix_circleftp_enabled: false,
            bdix_dhakaflix_enabled: false,
            bdix_probed: false,
            streaming_enabled: true,
            is_tv_mode: false,
            tv_enabled: true,
            tv_config_popup: false,
            tv_channels: Vec::new(),
            tv_playlists: Vec::new(),
            tv_manager_selected: 0,
            tv_input_active: false,
            tv_input_buffer: crate::tui::text::TextInputBuffer::new(),
            tv_input_is_file: false,
            addons_enabled: false,
            installed_addons: Vec::new(),
            addon_manager_popup: false,
            addon_manager_selected: 0,
            addon_input_active: false,
            addon_input_buffer: crate::tui::text::TextInputBuffer::new(),
            history: crate::history::HistoryManager::new(),
            favorites: crate::favorites::FavoritesManager::new(),
            favorites_focus: false,
            exit_armed_at: None,
            ime_shown: false,
            discover_focus: None,
            home_top_focus: HomeTopFocus::None,
            home_deck_tab: HomeDeckTab::default(),
            favorites_landing_state: ListState::default(),
        }
    }
}

const fn cache_capacity(n: usize) -> std::num::NonZeroUsize {
    match std::num::NonZeroUsize::new(n) {
        Some(value) => value,
        None => std::num::NonZeroUsize::MIN,
    }
}

impl AppState {
    pub fn mode(&self) -> AppMode {
        if self.is_tv_mode {
            AppMode::Tv
        } else {
            AppMode::Streaming
        }
    }
    pub fn reset_details_view(&mut self) {
        self.details_pane = DetailsPane::default();
        self.selected_season = 1;
        self.selected_episode = 1;
        self.season_list_state.select(None);
        self.episode_list_state.select(None);
        self.language_list_state.select(None);
        self.resource_list_state.select(None);
        self.show_overview_modal = false;
        self.subtitle_popup = false;
        self.is_download_subtitle_popup = false;
        self.player_picker_popup = false;
        self.is_resolving_playback = false;
        self.is_waiting_for_download_stream = false;
        self.pending_play_link = None;
        self.pending_playback_source = None;
        self.selected_details = None;
        self.selected_resources.clear();
        self.addon_stream_statuses.clear();
        self.addon_stream_filter = None;
        self.active_subject_id = None;
        self.available_seasons.clear();
        self.available_episode_numbers.clear();
        self.is_fetching_streams = false;
        self.stream_error = None;
        self.language_chosen = false;
        self.stream_pool.clear();
        self.pending_episode_fetch = None;
        self.poster_image = None;
        self.poster_protocol = None;
    }

    pub fn set_mode(&mut self, mode: AppMode) {
        match mode {
            AppMode::Streaming => {
                self.is_tv_mode = false;
            }
            AppMode::Tv => {
                self.is_tv_mode = true;
            }
        }
    }
    pub fn provider_for_subject(&self, subject_id: &str) -> ProviderKind {
        self.search_results
            .iter()
            .find(|r| r.id == subject_id)
            .map(|r| r.provider)
            .or_else(|| {
                self.selected_details
                    .as_ref()
                    .filter(|d| d.id.value == subject_id)
                    .map(|d| d.id.provider)
            })
            .or_else(|| self.selected_resources.first().map(|r| r.provider))
            .unwrap_or(self.active_provider)
    }

    pub fn current_subject_provider(&self) -> ProviderKind {
        self.active_subject_id
            .as_deref()
            .map(|id| self.provider_for_subject(id))
            .unwrap_or(self.active_provider)
    }

    pub fn is_selected_details_favorited(&self) -> bool {
        let Some(details) = &self.selected_details else {
            return false;
        };
        let details_subject_id = self.active_subject_id.as_deref().unwrap_or("");
        let title = &details.title;
        let type_val = if details.is_series() { 2 } else { 1 };
        let year = details.year.as_deref().unwrap_or("N/A");
        let provider = self.provider_for_subject(details_subject_id);
        self.favorites.is_favorite(&crate::models::SubjectIdentity {
            provider: provider.cache_key(),
            subject_id: details_subject_id,
            title,
            stype: type_val,
            release_year: year,
        })
    }

    pub fn provider_enabled(&self, p: ProviderKind) -> bool {
        match p {
            ProviderKind::MovieBox => self.moviebox_enabled,
            ProviderKind::FourKHdHub => self.fourkhdhub_enabled,
            ProviderKind::Dramachi => self.dramachi_enabled,
            ProviderKind::BdixCircleFtp => self.bdix_circleftp_enabled,
            ProviderKind::BdixDhakaFlix => self.bdix_dhakaflix_enabled,
            ProviderKind::Addons => self.addons_enabled,
        }
    }

    pub fn set_provider_enabled(&mut self, p: ProviderKind, enabled: bool) {
        match p {
            ProviderKind::MovieBox => self.moviebox_enabled = enabled,
            ProviderKind::FourKHdHub => self.fourkhdhub_enabled = enabled,
            ProviderKind::Dramachi => self.dramachi_enabled = enabled,
            ProviderKind::BdixCircleFtp => self.bdix_circleftp_enabled = enabled,
            ProviderKind::BdixDhakaFlix => self.bdix_dhakaflix_enabled = enabled,
            ProviderKind::Addons => self.addons_enabled = enabled,
        }
    }

    pub fn available_providers(&self) -> Vec<ProviderKind> {
        let mut providers: Vec<ProviderKind> = crate::models::ProviderKind::ENABLED
            .into_iter()
            .filter(|p| self.provider_enabled(*p))
            .collect();
        if self.addons_enabled || !self.installed_addons.is_empty() {
            providers.push(ProviderKind::Addons);
        }
        providers
    }

    pub fn next_provider(&self) -> ProviderKind {
        let available_providers = self.available_providers();
        if available_providers.is_empty() {
            return self.active_provider;
        }
        match available_providers
            .iter()
            .position(|provider| *provider == self.active_provider)
        {
            None => available_providers[0],
            Some(current) => available_providers[(current + 1) % available_providers.len()],
        }
    }

    pub fn notify(
        &mut self,
        kind: crate::tui::overlay::NotificationKind,
        title: impl Into<String>,
        message: impl Into<String>,
    ) {
        let title = title.into();
        let message = message.into();

        let same_category = |a: &str, b: &str| -> bool {
            if a.eq_ignore_ascii_case(b) {
                return true;
            }
            let is_playback = |s: &str| {
                let lower = s.to_lowercase();
                lower.contains("playback")
                    || lower.contains("player")
                    || lower.contains("stream")
                    || lower.contains("mpv")
            };
            let is_download = |s: &str| s.to_lowercase().contains("download");
            let is_update = |s: &str| {
                let lower = s.to_lowercase();
                lower.contains("update") || lower.contains("upgrade")
            };
            let is_cache = |s: &str| s.to_lowercase().contains("cache");
            (is_playback(a) && is_playback(b))
                || (is_download(a) && is_download(b))
                || (is_update(a) && is_update(b))
                || (is_cache(a) && is_cache(b))
        };

        if let Some(existing) = self
            .notifications
            .iter_mut()
            .find(|n| same_category(&n.title, &title))
        {
            *existing = crate::tui::overlay::Notification::new(kind, title, message);
            return;
        }

        self.make_room_for_notification();
        self.notifications
            .push_back(crate::tui::overlay::Notification::new(kind, title, message));
    }

    /// Drops the least important notification when three are already shown.
    /// Sticky notices (a running torrent) and errors are kept as long as
    /// anything else can go instead.
    fn make_room_for_notification(&mut self) {
        if self.notifications.len() < 3 {
            return;
        }
        let removable = self
            .notifications
            .iter()
            .position(|n| {
                !n.sticky && n.kind != crate::tui::overlay::NotificationKind::Error
            })
            .or_else(|| self.notifications.iter().position(|n| !n.sticky))
            .unwrap_or(0);
        self.notifications.remove(removable);
    }

    /// Shows (or updates in place) a notification that does not expire.
    /// It stays until [`AppState::dismiss_notification`] removes it.
    pub fn notify_sticky(
        &mut self,
        kind: crate::tui::overlay::NotificationKind,
        title: impl Into<String>,
        message: impl Into<String>,
    ) {
        let title = title.into();
        let message = message.into();
        if let Some(existing) = self
            .notifications
            .iter_mut()
            .find(|n| n.sticky && n.title == title)
        {
            existing.kind = kind;
            existing.message = message;
            return;
        }
        self.make_room_for_notification();
        self.notifications
            .push_back(crate::tui::overlay::Notification::new_sticky(
                kind, title, message,
            ));
    }

    pub fn has_sticky_notification(&self, title: &str) -> bool {
        self.notifications
            .iter()
            .any(|n| n.sticky && n.title == title)
    }

    /// Removes the sticky notification with this title, if it is showing.
    pub fn dismiss_notification(&mut self, title: &str) {
        self.notifications
            .retain(|n| !(n.sticky && n.title == title));
    }

    pub fn expire_notifications(&mut self) {
        self.notifications
            .retain(|notification| !notification.expired());
    }

    pub const STATUS_TICKS_SHORT: u16 = 90;
    pub const STATUS_TICKS_DEFAULT: u16 = 150;
    pub const STATUS_TICKS_LONG: u16 = 240;

    pub fn set_status(&mut self, message: impl Into<String>, timer: usize) {
        self.status_message = message.into();
        self.status_timer = timer;
    }

    pub fn set_status_default(&mut self, msg: impl Into<String>) {
        self.set_status(msg, Self::STATUS_TICKS_DEFAULT as usize);
    }

    pub fn set_status_short(&mut self, msg: impl Into<String>) {
        self.set_status(msg, Self::STATUS_TICKS_SHORT as usize);
    }

    pub fn set_status_long(&mut self, msg: impl Into<String>) {
        self.set_status(msg, Self::STATUS_TICKS_LONG as usize);
    }

    pub fn result_metrics(&self, results_height: u16, results_width: u16) -> ResultMetrics {
        let max_rows = results_height.saturating_sub(1).max(3);
        let poster_rows_eff = self.poster_rows.max(3).min(max_rows);
        let row_height = poster_rows_eff.saturating_add(1).max(4);
        let columns = crate::tui::state::result_columns_for(results_width);
        let total_gutters = columns.saturating_sub(1);
        let usable_width = results_width.saturating_sub(total_gutters);
        let col_width = (usable_width / columns.max(1)).max(1);
        let visible_rows = (results_height as usize / row_height as usize).max(1);
        let visible_items = visible_rows * columns as usize;
        ResultMetrics {
            poster_rows_eff,
            row_height,
            visible_items,
            columns,
            col_width,
        }
    }

    pub fn normalize_result_view(&mut self) {
        let total = self.search_results.len();
        if total == 0 {
            self.result_scroll = 0;
            self.search_list_state.select(None);
            return;
        }
        let selected = self
            .search_list_state
            .selected()
            .unwrap_or(0)
            .min(total - 1);
        self.search_list_state.select(Some(selected));
        let columns = match self.last_result_metrics {
            Some(metrics) => metrics.columns as usize,
            None => 1,
        };
        let visible_items = match self.last_result_metrics {
            Some(metrics) => metrics.visible_items,
            None => 8,
        };
        let cols = columns.max(1);
        let rows_visible = (visible_items / cols).max(1);
        let selected_row = selected / cols;
        let mut base_row = self.result_scroll / cols;
        if selected_row < base_row || selected_row >= base_row + rows_visible {
            base_row = selected_row.saturating_sub(rows_visible / 2);
        }
        let max_base = total.saturating_sub(rows_visible * cols) / cols;
        let base_row = base_row.min(max_base);
        self.result_scroll = base_row * cols;
    }

    pub fn effective_visible_items(&self) -> usize {
        self.last_result_metrics
            .map(|metrics| metrics.visible_items)
            .unwrap_or(8)
    }

    pub fn effective_row_height(&self) -> u16 {
        self.last_result_metrics
            .map(|metrics| metrics.row_height)
            .unwrap_or(4)
    }

    const FAILED_POSTER_TTL_SECS: u64 = 600;

    pub fn failed_poster_recently(&mut self, id: &str) -> bool {
        match self.failed_posters.peek(id) {
            Some(failed_at) if failed_at.elapsed().as_secs() < Self::FAILED_POSTER_TTL_SECS => true,
            Some(_) => {
                self.failed_posters.pop(id);
                false
            }
            None => false,
        }
    }
    pub fn open_provider_popup(&mut self) {
        if self.is_tv_mode {
            return;
        }
        let available = self.available_providers();
        let current_idx = available
            .iter()
            .position(|p| *p == self.active_provider)
            .unwrap_or(0);
        self.show_provider_popup = true;
        self.provider_list_state.select(Some(current_idx));
        self.input_mode = InputMode::Normal;
        self.home_top_focus = HomeTopFocus::None;
        self.discover_focus = None;
        self.favorites_focus = false;
    }

    pub fn has_active_modal(&self) -> bool {
        self.show_help
            || self.show_theme_popup
            || self.show_browse_popup
            || self.show_provider_popup
            || self.show_settings_popup
            || self.show_sources_popup
            || self.addon_manager_popup
            || self.tv_config_popup
            || self.player_picker_popup
            || self.subtitle_popup
            || self.is_download_subtitle_popup
            || self.show_overview_modal
            || (self.update_available.is_some() && self.input_mode != InputMode::Editing)
            || self.is_updating
            || (self.input_mode == InputMode::Editing && !self.search_suggestions.is_empty())
    }

    pub fn clear_search_state(&mut self) {
        self.search_query.clear();
        self.search_results.clear();
        self.search_error = None;
        self.search_suggestions.clear();
        self.suggest_cache.clear();
        self.suggest_index = None;
        self.search_preview = None;
        self.preview_loading = false;
        self.active_browse_preset = None;
        self.active_addon_catalog = None;
        self.browse_metrics.clear();
        self.clear_poster_cache();
        self.result_scroll = 0;
        self.search_list_state.select(None);
        self.is_homepage_mode = false;
        self.favorites_focus = false;
        self.discover_focus = None;
        self.home_top_focus = HomeTopFocus::None;
        self.favorites_landing_state.select(None);
        self.has_search_settled = false;
        self.search_exhausted = false;
    }

    pub fn clear_details_state(&mut self) {
        self.active_subject_id = None;
        self.selected_details = None;
        self.selected_resources.clear();
        self.addon_stream_statuses.clear();
        self.addon_stream_filter = None;
        self.is_fetching_streams = false;
        self.pending_episode_fetch = None;
        self.auto_play_on_ready = false;
        self.stream_error = None;
        self.details_error = None;
        self.available_seasons.clear();
        self.available_episode_numbers.clear();
        self.season_list_state.select(None);
        self.episode_list_state.select(None);
        self.resource_list_state.select(None);
        self.language_list_state.select(None);
        self.details_pane = DetailsPane::Streams;
        self.has_streams_settled = false;
    }

    /// Addon tabs for the Streams filter bar, busiest first: addons with the
    /// most streams lead, then addons still loading, then empty, blocked and
    /// failed ones. Recomputed on every draw, so the order follows the live
    /// counts as slower addons answer. Equal counts keep the install order.
    pub fn addon_filter_tabs(&self) -> Vec<crate::providers::addons::AddonStreamStatus> {
        use crate::providers::addons::AddonStreamState;

        let mut tabs = self.addon_filter_tabs_unsorted();
        tabs.sort_by_key(|tab| match &tab.state {
            AddonStreamState::Found(n) => (0u8, std::cmp::Reverse(*n)),
            AddonStreamState::Loading => (1, std::cmp::Reverse(0)),
            AddonStreamState::Empty => (2, std::cmp::Reverse(0)),
            AddonStreamState::Blocked => (3, std::cmp::Reverse(0)),
            AddonStreamState::Failed(_) => (4, std::cmp::Reverse(0)),
        });
        tabs
    }

    fn addon_filter_tabs_unsorted(&self) -> Vec<crate::providers::addons::AddonStreamStatus> {
        if !self.addon_stream_statuses.is_empty() {
            return self.addon_stream_statuses.clone();
        }
        if self.current_subject_provider() != ProviderKind::Addons || self.selected_resources.is_empty() {
            return Vec::new();
        }
        let mut names: Vec<String> = Vec::new();
        for rel in &self.selected_resources {
            for mirror in &rel.mirrors {
                let raw = crate::providers::addons::extract_addon_name_from_label(&mirror.label);
                if !raw.is_empty() && !names.iter().any(|n| n.eq_ignore_ascii_case(raw)) {
                    names.push(raw.to_string());
                }
            }
        }
        names
            .into_iter()
            .map(|name| {
                let count = self
                    .selected_resources
                    .iter()
                    .filter(|r| crate::providers::addons::release_matches_addon(r, &name))
                    .count();
                crate::providers::addons::AddonStreamStatus {
                    name,
                    state: if count > 0 {
                        crate::providers::addons::AddonStreamState::Found(count)
                    } else {
                        crate::providers::addons::AddonStreamState::Empty
                    },
                }
            })
            .collect()
    }

    pub fn visible_resources(&self) -> Vec<&Release> {
        match &self.addon_stream_filter {
            Some(addon_name) => self
                .selected_resources
                .iter()
                .filter(|r| crate::providers::addons::release_matches_addon(r, addon_name))
                .collect(),
            None => self.selected_resources.iter().collect(),
        }
    }

    pub fn set_addon_filter(&mut self, filter: Option<String>) {
        self.addon_stream_filter = filter;
        let visible_len = self.visible_resources().len();
        self.resource_list_state
            .select(if visible_len == 0 { None } else { Some(0) });
    }

    pub fn cycle_addon_filter(&mut self, forward: bool) {
        let tabs = self.addon_filter_tabs();
        if tabs.is_empty() {
            return;
        }
        let mut options: Vec<Option<String>> = Vec::with_capacity(tabs.len() + 1);
        options.push(None);
        for tab in tabs {
            options.push(Some(tab.name));
        }
        let current_idx = self
            .addon_stream_filter
            .as_deref()
            .and_then(|cur| {
                options.iter().position(|opt| {
                    opt.as_deref()
                        .is_some_and(|name| name.eq_ignore_ascii_case(cur))
                })
            })
            .unwrap_or(0);
        let next_idx = if forward {
            (current_idx + 1) % options.len()
        } else {
            (current_idx + options.len() - 1) % options.len()
        };
        self.set_addon_filter(options[next_idx].clone());
    }

    pub fn favorites_available(&self) -> bool {
        self.streaming_enabled && !self.is_tv_mode
    }

    pub fn favorites_landing_visible(&self) -> bool {
        self.favorites_available()
            && !self.favorites.items.is_empty()
            && !(self.input_mode == InputMode::Editing && !self.search_suggestions.is_empty())
    }

    pub fn favorites_landing_items(&self) -> Vec<&crate::favorites::FavoriteItem> {
        let mut items: Vec<&crate::favorites::FavoriteItem> = self.favorites.items.iter().collect();
        items.sort_by_key(|item| std::cmp::Reverse(item.added_at));
        items.truncate(5);
        items
    }

    pub fn continue_watching_items(&self) -> Vec<&crate::history::WatchHistoryItem> {
        let mut items: Vec<&crate::history::WatchHistoryItem> = self
            .history
            .recent
            .iter()
            .filter(|item| item.is_in_progress())
            .collect();
        items.sort_by_key(|item| std::cmp::Reverse(item.timestamp));
        items.truncate(5);
        items
    }

    pub fn continue_watching_available(&self) -> bool {
        self.streaming_enabled
            && !self.is_tv_mode
            && self.history.recent.iter().any(|item| item.is_in_progress())
    }

    pub fn effective_home_deck_tab(&self) -> HomeDeckTab {
        let cw_has = self.continue_watching_available();
        let fav_has = self.favorites_available() && !self.favorites.items.is_empty();
        match self.home_deck_tab {
            HomeDeckTab::ContinueWatching => {
                if cw_has {
                    HomeDeckTab::ContinueWatching
                } else if fav_has {
                    HomeDeckTab::Favorites
                } else {
                    HomeDeckTab::ContinueWatching
                }
            }
            HomeDeckTab::Favorites => {
                if fav_has {
                    HomeDeckTab::Favorites
                } else if cw_has {
                    HomeDeckTab::ContinueWatching
                } else {
                    HomeDeckTab::Favorites
                }
            }
        }
    }

    /// True when the empty home screen shows the Discover Categories card
    /// (no continue-watching / favorites deck, nothing searched yet).
    pub fn discover_landing_available(&self) -> bool {
        !self.is_tv_mode
            && !self.landing_deck_visible()
            && self.search_results.is_empty()
            && self.search_query.trim().is_empty()
            && self.active_browse_preset.is_none()
            && self.active_addon_catalog.is_none()
            && !self.has_active_modal()
    }

    /// Number of selectable rows in the Discover Categories card.
    pub fn discover_row_count(&self) -> usize {
        4
    }

    pub fn landing_deck_visible(&self) -> bool {
        (self.continue_watching_available() || self.favorites_landing_visible())
            && !(self.input_mode == InputMode::Editing && !self.search_suggestions.is_empty())
    }

    pub fn landing_deck_items_count(&self) -> usize {
        match self.effective_home_deck_tab() {
            HomeDeckTab::ContinueWatching => self.continue_watching_items().len(),
            HomeDeckTab::Favorites => self.favorites_landing_items().len(),
        }
    }

    pub fn landing_deck_total_items_count(&self) -> usize {
        match self.effective_home_deck_tab() {
            HomeDeckTab::ContinueWatching => self
                .history
                .recent
                .iter()
                .filter(|i| i.is_in_progress())
                .count(),
            HomeDeckTab::Favorites => self.favorites.items.len(),
        }
    }

    pub fn cycle_home_deck_tab(&mut self) {
        let cw_has = self.continue_watching_available();
        let fav_has = self.favorites_available() && !self.favorites.items.is_empty();
        if cw_has && fav_has {
            self.home_deck_tab = match self.effective_home_deck_tab() {
                HomeDeckTab::ContinueWatching => HomeDeckTab::Favorites,
                HomeDeckTab::Favorites => HomeDeckTab::ContinueWatching,
            };
            if self.favorites_focus {
                self.favorites_landing_state.select(Some(0));
            }
        }
    }

    pub fn loading_dots(&self) -> &'static str {
        match (self.tick_count / 4) % 4 {
            0 => "",
            1 => ".",
            2 => "..",
            _ => "...",
        }
    }
    pub fn settings_next_category(&mut self) {
        self.settings_category = self.settings_category.next();
        self.settings_selected_row = 0;
        self.settings_download_dir_input = None;
    }

    pub fn settings_previous_category(&mut self) {
        self.settings_category = self.settings_category.previous();
        self.settings_selected_row = 0;
        self.settings_download_dir_input = None;
    }

    pub fn settings_select_category(&mut self, cat: SettingsCategory) {
        if self.settings_category != cat {
            self.settings_category = cat;
            self.settings_selected_row = 0;
            self.settings_download_dir_input = None;
        }
    }

    pub fn settings_row_up(&mut self) {
        let count = self.settings_category.row_count();
        if count > 0 {
            self.settings_selected_row = (self.settings_selected_row + count - 1) % count;
        }
    }

    pub fn settings_row_down(&mut self) {
        let count = self.settings_category.row_count();
        if count > 0 {
            self.settings_selected_row = (self.settings_selected_row + 1) % count;
        }
    }

    pub fn settings_player_choices(&self) -> Vec<&str> {
        let mut choices: Vec<&str> = Vec::with_capacity(self.available_players.len());
        for player in &self.available_players {
            let key = player.config_key();
            if !choices.iter().any(|&c| c.eq_ignore_ascii_case(key)) {
                choices.push(key);
            }
        }
        choices
    }

    pub fn cycle_settings_player(&mut self, forward: bool) {
        let choices = self.settings_player_choices();
        if choices.is_empty() {
            return;
        }
        let current_key = self.default_player.as_deref();
        let current_idx = current_key
            .and_then(|k| choices.iter().position(|&opt| opt.eq_ignore_ascii_case(k)))
            .unwrap_or(0);

        let total = choices.len();
        let next_idx = if forward {
            (current_idx + 1) % total
        } else {
            (current_idx + total - 1) % total
        };

        self.default_player = Some(choices[next_idx].to_string());
    }

    pub fn cycle_settings_theme(&mut self, forward: bool) -> String {
        let themes = crate::tui::theme::AVAILABLE_THEMES;
        let total = themes.len();
        let current_idx = themes
            .iter()
            .position(|&t| t.eq_ignore_ascii_case(&self.active_theme_kind))
            .unwrap_or(0);

        let next_idx = if forward {
            (current_idx + 1) % total
        } else {
            (current_idx + total - 1) % total
        };

        let next_theme = themes[next_idx].to_string();
        self.active_theme_kind = next_theme.clone();
        self.theme_is_auto = false;
        next_theme
    }

    pub fn can_disable_streaming_mode(&self) -> bool {
        self.tv_enabled || self.addons_enabled
    }

    pub fn can_disable_tv_mode(&self) -> bool {
        self.streaming_enabled
    }
    pub fn expand_download_path(raw: &str) -> Option<std::path::PathBuf> {
        let clean = raw.trim_matches(|c| c == '\'' || c == '"').trim();
        if clean.is_empty()
            || clean.eq_ignore_ascii_case("default")
            || clean.eq_ignore_ascii_case("reset")
            || clean == "<path>"
            || clean == "path"
            || clean == "<dir>"
            || clean == "dir"
        {
            return None;
        }
        let pb = if let Some(stripped) = clean
            .strip_prefix("~/")
            .or_else(|| clean.strip_prefix("~\\"))
        {
            if let Some(home) = dirs::home_dir() {
                home.join(stripped)
            } else {
                std::path::PathBuf::from(clean)
            }
        } else if clean == "~" {
            dirs::home_dir().unwrap_or_else(|| std::path::PathBuf::from(clean))
        } else {
            std::path::PathBuf::from(clean)
        };
        Some(pb)
    }
    pub fn clear_poster_cache(&mut self) {
        self.poster_image = None;
        self.poster_protocol = None;
        self.search_posters.clear();
        self.search_poster_protocols.clear();
        self.failed_posters.clear();
        self.in_flight_posters.clear();
    }

    pub fn clear_poster_protocols(&mut self) {
        self.poster_protocol = None;
        self.search_poster_protocols.clear();
    }
}

pub fn cycle_list_selection(state: &mut ListState, total_items: usize, forward: bool) {
    if total_items == 0 {
        state.select(None);
        return;
    }
    let max = total_items.saturating_sub(1);
    let next = if forward {
        match state.selected() {
            Some(i) if i >= max => 0,
            Some(i) => i + 1,
            None => 0,
        }
    } else {
        match state.selected() {
            Some(0) | None => max,
            Some(i) => i.saturating_sub(1),
        }
    };
    state.select(Some(next));
}

pub fn step_list_selection(state: &mut ListState, total_items: usize, step: isize) {
    if total_items == 0 {
        state.select(None);
        return;
    }
    let max = total_items.saturating_sub(1);
    let cur = state.selected().unwrap_or(0);
    let next = if step < 0 {
        cur.saturating_sub(step.unsigned_abs())
    } else {
        (cur + step as usize).min(max)
    };
    state.select(Some(next));
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum TvManagerRow {
    Playlist(usize),
    AddPlaylist,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum AddonManagerRow {
    Addon(usize),
    AddUrl,
}

impl AppState {
    pub fn tv_manager_rows(&self) -> Vec<TvManagerRow> {
        let mut rows = Vec::with_capacity(self.tv_playlists.len() + 1);
        for index in 0..self.tv_playlists.len() {
            rows.push(TvManagerRow::Playlist(index));
        }
        rows.push(TvManagerRow::AddPlaylist);
        rows
    }

    pub fn step_tv_manager_selected(&mut self, step: isize) {
        let rows_len = self.tv_manager_rows().len();
        if rows_len == 0 {
            self.tv_manager_selected = 0;
            return;
        }
        if step > 0 {
            self.tv_manager_selected = (self.tv_manager_selected + step as usize) % rows_len;
        } else {
            let back = (-step) as usize % rows_len;
            self.tv_manager_selected = (self.tv_manager_selected + rows_len - back) % rows_len;
        }
    }

    pub fn first_tv_manager_selected(&mut self) {
        self.tv_manager_selected = 0;
    }

    pub fn last_tv_manager_selected(&mut self) {
        let total = self.tv_manager_rows().len();
        self.tv_manager_selected = total.saturating_sub(1);
    }

    pub fn addon_manager_rows(&self) -> Vec<AddonManagerRow> {
        let mut rows = Vec::with_capacity(self.installed_addons.len() + 1);
        for index in 0..self.installed_addons.len() {
            rows.push(AddonManagerRow::Addon(index));
        }
        rows.push(AddonManagerRow::AddUrl);
        rows
    }

    pub fn step_addon_manager_selected(&mut self, step: isize) {
        let total = self.addon_manager_rows().len();
        if total == 0 {
            self.addon_manager_selected = 0;
            return;
        }
        if step > 0 {
            self.addon_manager_selected = (self.addon_manager_selected + step as usize) % total;
        } else {
            let s = (-step) as usize % total;
            self.addon_manager_selected = (self.addon_manager_selected + total - s) % total;
        }
    }

    pub fn first_addon_manager_selected(&mut self) {
        self.addon_manager_selected = 0;
    }

    pub fn last_addon_manager_selected(&mut self) {
        let total = self.addon_manager_rows().len();
        self.addon_manager_selected = total.saturating_sub(1);
    }

    pub fn max_addon_name_width(&self) -> usize {
        self.installed_addons
            .iter()
            .map(|a| crate::tui::text::width(&a.name))
            .max()
            .unwrap_or(0)
    }
    pub fn open_overview_modal(&mut self, title: String, content: String) {
        self.overview_modal_title = title;
        self.overview_modal_content = content;
        self.overview_modal_scroll = 0;
        self.show_overview_modal = true;
    }

    pub fn close_overview_modal(&mut self) {
        self.show_overview_modal = false;
        self.overview_modal_scroll = 0;
    }

    pub fn series_synopsis(&self) -> Option<(String, String)> {
        let details = self.selected_details.as_ref()?;
        let raw_title = if !details.title.trim().is_empty() {
            &details.title
        } else if let Some(res) = self
            .search_results
            .iter()
            .find(|r| self.active_subject_id.as_deref() == Some(&r.id))
        {
            &res.title
        } else {
            "Unknown Title"
        };
        let title = crate::providers::moviebox::clean_moviebox_title(raw_title);
        let intro = details
            .description
            .as_deref()
            .filter(|s| !s.trim().is_empty())
            .or_else(|| {
                self.search_preview
                    .as_ref()
                    .filter(|p| {
                        p.id.value == details.id.value && p.id.provider == details.id.provider
                    })
                    .and_then(|p| p.description.as_deref())
            })
            .unwrap_or("No description available.");

        Some((format!("{title} · Synopsis"), intro.to_string()))
    }

    pub fn episode_overview(&self) -> Option<(String, String)> {
        let details = self.selected_details.as_ref()?;
        let raw_title = if !details.title.trim().is_empty() {
            &details.title
        } else if let Some(res) = self
            .search_results
            .iter()
            .find(|r| self.active_subject_id.as_deref() == Some(&r.id))
        {
            &res.title
        } else {
            "Unknown Title"
        };
        let title = crate::providers::moviebox::clean_moviebox_title(raw_title);

        let season_idx = self.season_list_state.selected().unwrap_or(0);
        let se_num = self
            .available_seasons
            .get(season_idx)
            .map(|s| s.number)
            .unwrap_or(1);
        let selected_ep_idx = self.episode_list_state.selected().unwrap_or(0);
        let ep_num = self
            .available_episode_numbers
            .get(season_idx)
            .and_then(|nums| nums.get(selected_ep_idx).copied())
            .unwrap_or(selected_ep_idx + 1);

        let ep_match = details
            .seasons
            .iter()
            .find(|s| s.number == se_num)
            .and_then(|s| s.episodes.iter().find(|e| e.number == ep_num));

        let ep_title = ep_match
            .and_then(|e| e.title.as_deref())
            .map(|t| t.trim())
            .filter(|t| !t.is_empty());

        let ep_overview = ep_match
            .and_then(|e| e.overview.as_deref())
            .map(|o| o.trim())
            .filter(|o| !o.is_empty())?;

        let modal_title = if let Some(t) = ep_title {
            format!("{title} · S{se_num:02}E{ep_num:02} · {t}")
        } else {
            format!("{title} · S{se_num:02}E{ep_num:02}")
        };

        Some((modal_title, ep_overview.to_string()))
    }

    pub fn active_overview(&self) -> Option<(String, String)> {
        if self.details_pane == DetailsPane::Episodes {
            self.episode_overview().or_else(|| self.series_synopsis())
        } else {
            self.series_synopsis()
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn state_with(results: usize) -> AppState {
        let mut state = AppState::default();
        for i in 0..results {
            state.search_results.push(crate::models::SearchResult {
                id: i.to_string(),
                title: format!("T{i}"),
                stype: 1,
                release_year: "2020".to_string(),
                cover_url: None,
                season: 0,
                episode: 0,
                provider: crate::providers::models::ProviderKind::MovieBox,
            });
        }
        state
    }

    #[test]
    fn columns_follow_width_tiers() {
        assert_eq!(result_columns_for(60), 1);
        assert_eq!(result_columns_for(80), 1);
        assert_eq!(result_columns_for(110), 2);
        assert_eq!(result_columns_for(159), 2);
        assert_eq!(result_columns_for(160), 3);
        assert_eq!(result_columns_for(219), 3);
        assert_eq!(result_columns_for(220), 4);
        assert_eq!(result_columns_for(279), 4);
        assert_eq!(result_columns_for(280), 5);
        assert_eq!(result_columns_for(320), 5);
    }

    #[test]
    fn addons_provider_appears_when_enabled() {
        let mut s = AppState {
            addons_enabled: true,
            ..Default::default()
        };
        assert!(s.available_providers().contains(&ProviderKind::Addons));
        s.addons_enabled = false;
        assert!(!s.available_providers().contains(&ProviderKind::Addons));
    }

    #[test]
    fn poster_rows_clamp_to_viewport() {
        let state = AppState {
            poster_rows: 12,
            ..Default::default()
        };
        let metrics = state.result_metrics(10, 100);
        assert!(metrics.poster_rows_eff <= 9, "rows must fit viewport");
        assert!(metrics.visible_items >= 1);
    }

    #[test]
    fn normalize_clamps_selection_and_aligns_scroll() {
        let mut state = state_with(20);
        state.last_result_metrics = Some(ResultMetrics {
            poster_rows_eff: 3,
            row_height: 4,
            visible_items: 9,
            columns: 3,
            col_width: 60,
        });
        state.search_list_state.select(Some(25));
        state.result_scroll = 50;
        state.normalize_result_view();
        assert_eq!(state.search_list_state.selected(), Some(19));
        assert!(state.result_scroll <= 11);
        assert_eq!(state.result_scroll % 3, 0);
    }

    #[test]
    fn normalize_keeps_selection_visible_when_scrolling_down() {
        let mut state = state_with(30);
        state.last_result_metrics = Some(ResultMetrics {
            poster_rows_eff: 3,
            row_height: 4,
            visible_items: 6,
            columns: 3,
            col_width: 40,
        });
        state.search_list_state.select(Some(10));
        state.result_scroll = 0;
        state.normalize_result_view();
        assert_eq!(state.result_scroll, 6);
        assert!(state.search_list_state.selected().unwrap() < state.result_scroll + 6);
    }

    #[test]
    fn test_has_active_modal_detection() {
        let mut state = AppState::default();
        assert!(!state.has_active_modal());

        state.show_help = true;
        assert!(state.has_active_modal());
        state.show_help = false;

        state.show_theme_popup = true;
        assert!(state.has_active_modal());
        state.show_theme_popup = false;

        state.show_browse_popup = true;
        assert!(state.has_active_modal());
        state.show_browse_popup = false;
        state.show_provider_popup = true;
        assert!(state.has_active_modal());
        state.show_provider_popup = false;

        state.addon_manager_popup = true;
        assert!(state.has_active_modal());
        state.addon_manager_popup = false;

        state.tv_config_popup = true;
        assert!(state.has_active_modal());
        state.tv_config_popup = false;

        state.player_picker_popup = true;
        assert!(state.has_active_modal());
        state.player_picker_popup = false;

        state.subtitle_popup = true;
        assert!(state.has_active_modal());
        state.subtitle_popup = false;

        state.is_download_subtitle_popup = true;
        assert!(state.has_active_modal());
        state.is_download_subtitle_popup = false;

        state.update_available = Some(("v2.0.0".to_string(), "Notes".to_string()));
        assert!(state.has_active_modal());
        state.input_mode = InputMode::Editing;
        assert!(!state.has_active_modal());
        state.input_mode = InputMode::Normal;
        state.update_available = None;

        state.input_mode = InputMode::Editing;
        state.search_suggestions = vec!["suggestion".to_string()];
        assert!(state.has_active_modal());
        state.search_suggestions.clear();
        assert!(!state.has_active_modal());
        state.input_mode = InputMode::Normal;

        assert!(!state.has_active_modal());
    }

    #[test]
    fn test_favorites_landing_visible_conditions() {
        let mut state = AppState::default();
        state.favorites.items.clear();
        state.streaming_enabled = true;
        assert!(!state.favorites_landing_visible());
        state.favorites.items.push(crate::favorites::FavoriteItem {
            provider: "moviebox".to_string(),
            subject_id: "fav-1".to_string(),
            title: "Favorite Movie".to_string(),
            cover_url: None,
            stype: 1,
            release_year: "2024".to_string(),
            added_at: 0,
        });
        assert!(state.favorites_landing_visible());

        state.input_mode = InputMode::Editing;
        state.search_suggestions = vec!["suggestion".to_string()];
        assert!(!state.favorites_landing_visible());

        state.search_suggestions.clear();
        assert!(state.favorites_landing_visible());

        state.search_suggestions = vec!["suggestion".to_string()];
        state.input_mode = InputMode::Normal;
        assert!(state.favorites_landing_visible());
    }

    #[test]
    fn test_sticky_notification_does_not_expire_or_get_evicted() {
        use crate::tui::overlay::NotificationKind::Info;
        let mut state = AppState::default();
        state.notify_sticky(Info, "Torrent running", "Finding peers...");

        // Long past its normal lifetime, it is still there.
        state.notifications[0].expires_at =
            std::time::Instant::now() - std::time::Duration::from_secs(600);
        state.expire_notifications();
        assert!(state.has_sticky_notification("Torrent running"));

        // Other notifications come and go around it.
        for i in 0..6 {
            state.notify(Info, format!("Note {i}"), "text");
        }
        assert!(state.has_sticky_notification("Torrent running"));
        assert!(state.notifications.len() <= 3);

        // Updating keeps a single card and swaps the text.
        state.notify_sticky(Info, "Torrent running", "12 peers");
        let cards: Vec<_> = state
            .notifications
            .iter()
            .filter(|n| n.title == "Torrent running")
            .collect();
        assert_eq!(cards.len(), 1);
        assert_eq!(cards[0].message, "12 peers");

        state.dismiss_notification("Torrent running");
        assert!(!state.has_sticky_notification("Torrent running"));
    }

    #[test]
    fn test_notify_replaces_same_category_in_place() {
        let mut state = AppState::default();
        state.notify(
            crate::tui::overlay::NotificationKind::Info,
            "Preparing playback",
            "Resolving stream...",
        );
        assert_eq!(state.notifications.len(), 1);
        assert_eq!(state.notifications[0].title, "Preparing playback");
        assert_eq!(state.notifications[0].message, "Resolving stream...");

        state.notify(
            crate::tui::overlay::NotificationKind::Info,
            "Playback Cancelled",
            "Stream launch cancelled.",
        );
        assert_eq!(state.notifications.len(), 1);
        assert_eq!(state.notifications[0].title, "Playback Cancelled");
        assert_eq!(state.notifications[0].message, "Stream launch cancelled.");

        state.notify(
            crate::tui::overlay::NotificationKind::Info,
            "Opening Player",
            "Launching mpv.",
        );
        assert_eq!(state.notifications.len(), 1);
        assert_eq!(state.notifications[0].title, "Opening Player");

        state.notify(
            crate::tui::overlay::NotificationKind::Error,
            "4KHDHub Stream Unavailable",
            "Mirrors dead or expired.",
        );
        assert_eq!(state.notifications.len(), 1);
        assert_eq!(state.notifications[0].title, "4KHDHub Stream Unavailable");
        assert_eq!(state.notifications[0].message, "Mirrors dead or expired.");
        state.notify(
            crate::tui::overlay::NotificationKind::Info,
            "Preparing download",
            "Waiting for details...",
        );
        assert_eq!(state.notifications.len(), 2);
        assert_eq!(state.notifications[1].title, "Preparing download");

        state.notify(
            crate::tui::overlay::NotificationKind::Info,
            "Download Started",
            "Started: Movie.mkv",
        );
        assert_eq!(state.notifications.len(), 2);
        assert_eq!(state.notifications[1].title, "Download Started");
    }

    #[test]
    fn test_cycle_settings_player_dynamic_detection() {
        let mut state = AppState {
            available_players: vec![PlayerKind::Mpv],
            ..Default::default()
        };
        assert_eq!(state.settings_player_choices(), vec!["mpv"]);

        state.default_player = None;
        state.cycle_settings_player(true);
        assert_eq!(state.default_player.as_deref(), Some("mpv"));

        state.cycle_settings_player(true);
        assert_eq!(state.default_player.as_deref(), Some("mpv"));

        state.cycle_settings_player(false);
        assert_eq!(state.default_player.as_deref(), Some("mpv"));
    }
    #[test]
    fn test_step_list_selection() {
        let mut state = ListState::default();
        step_list_selection(&mut state, 0, 5);
        assert_eq!(state.selected(), None);

        step_list_selection(&mut state, 10, 5);
        assert_eq!(state.selected(), Some(5));

        step_list_selection(&mut state, 10, 10);
        assert_eq!(state.selected(), Some(9));

        step_list_selection(&mut state, 10, -3);
        assert_eq!(state.selected(), Some(6));

        step_list_selection(&mut state, 10, -20);
        assert_eq!(state.selected(), Some(0));
    }

    #[test]
    fn test_clear_poster_cache() {
        let mut state = AppState::default();
        state.in_flight_posters.insert("p1".to_string());
        state
            .failed_posters
            .put("p2".to_string(), std::time::Instant::now());
        state.clear_poster_cache();
        assert!(state.in_flight_posters.is_empty());
        assert!(state.failed_posters.is_empty());
        assert!(state.poster_image.is_none());
        assert!(state.poster_protocol.is_none());
    }

    #[test]
    fn addon_tabs_are_ordered_by_stream_count() {
        use crate::providers::addons::{AddonStreamState, AddonStreamStatus};
        let status = |name: &str, state| AddonStreamStatus {
            name: name.to_string(),
            state,
        };
        let state = AppState {
            addon_stream_statuses: vec![
                status("Broken", AddonStreamState::Failed("timeout".to_string())),
                status("Empty", AddonStreamState::Empty),
                status("Small", AddonStreamState::Found(1)),
                status("Slow", AddonStreamState::Loading),
                status("Big", AddonStreamState::Found(6)),
                status("Mid", AddonStreamState::Found(2)),
            ],
            ..Default::default()
        };
        let names: Vec<String> = state
            .addon_filter_tabs()
            .into_iter()
            .map(|t| t.name)
            .collect();
        assert_eq!(names, ["Big", "Mid", "Small", "Slow", "Empty", "Broken"]);
    }
}
